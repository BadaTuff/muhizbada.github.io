﻿const express = require("express");
const router = express.Router();

const ctrlTrips = require("../controllers/trips");
const ctrlAuth = require("../controllers/auth");
const jwt = require("jsonwebtoken");

const jwtSecret = process.env.JWT_SECRET || "travlrJwtSecret";

const requireAuth = (req, res, next) => {
  const authHeader = req.headers.authorization || "";
  const token = authHeader.startsWith("Bearer ")
    ? authHeader.substring(7)
    : null;

  if (!token) {
    return res.status(401).json({ message: "No token provided" });
  }

  jwt.verify(token, jwtSecret, (err, payload) => {
    if (err) {
      return res.status(401).json({ message: "Token invalid" });
    }
    req.user = payload;
    next();
  });
};

router
  .route("/trips")
  .get(ctrlTrips.tripsList)
  .post(requireAuth, ctrlTrips.tripsAddTrip);

router
  .route("/trips/:tripCode")
  .get(ctrlTrips.tripsFindByCode)
  .put(requireAuth, ctrlTrips.tripsUpdateTrip)
  .delete(requireAuth, ctrlTrips.tripsDeleteTrip);

router.post("/register", ctrlAuth.register);
router.post("/login", ctrlAuth.login);

module.exports = router;
