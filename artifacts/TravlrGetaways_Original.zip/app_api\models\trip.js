﻿const mongoose = require("mongoose");

const tripSchema = new mongoose.Schema({
  code:   { type: String, required: [true, "Trip code required"], unique: true, trim: true },
  name:   { type: String, required: [true, "Trip name required"], trim: true, maxlength: 120 },
  price:  { type: Number, required: true, min: [0, "Price must be positive"] },
  nights: { type: Number, required: true, min: [1, "At least 1 night"] },
  img:    { type: String, trim: true },
  summary:{ type: String, trim: true, maxlength: 500 },
  createdOn: { type: Date, default: Date.now }
}, { collection: "trips" });

module.exports = mongoose.model("Trip", tripSchema);
