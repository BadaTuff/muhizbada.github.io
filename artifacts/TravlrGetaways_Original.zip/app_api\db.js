﻿const mongoose = require("mongoose");
const dbURI = process.env.MONGODB_URI || "mongodb://127.0.0.1:27017/travlr";

mongoose.set("strictQuery", true);
mongoose.connect(dbURI);

mongoose.connection.on("connected", () => console.log(`Mongoose connected to ${dbURI}`));
mongoose.connection.on("error", err => console.error("Mongoose connection error:", err.message));
mongoose.connection.on("disconnected", () => console.warn("Mongoose disconnected"));

process.on("SIGINT", () => {
  mongoose.connection.close(() => {
    console.log("Mongoose disconnected on app termination");
    process.exit(0);
  });
});

module.exports = mongoose;
