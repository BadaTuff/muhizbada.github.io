﻿var express = require('express');
var router = express.Router();
const traveler = require('../controllers/traveler');

router.get('/', traveler.travelList);

module.exports = router;
