﻿const jwt = require("jsonwebtoken");
const User = require("../models/user");

const jwtSecret = process.env.JWT_SECRET || "travlrJwtSecret";
const jwtExpiry = "1h";

const sendJsonResponse = (res, status, content) => {
  res.status(status).json(content);
};

module.exports.register = async (req, res) => {
  try {
    const { username, password, name } = req.body;
    if (!username || !password) {
      return sendJsonResponse(res, 400, { message: "Username and password are required" });
    }

    const existing = await User.findOne({ username }).exec();
    if (existing) {
      return sendJsonResponse(res, 400, { message: "User already exists" });
    }

    const user = new User({
      username,
      name: name || username,
      passwordHash: ""
    });

    await user.setPassword(password);
    await user.save();

    return sendJsonResponse(res, 201, { message: "User registered" });
  } catch (err) {
    return sendJsonResponse(res, 500, { message: "Registration failed", error: err.message });
  }
};

module.exports.login = async (req, res) => {
  try {
    const { username, password } = req.body;
    if (!username || !password) {
      return sendJsonResponse(res, 400, { message: "Username and password are required" });
    }

    const user = await User.findOne({ username }).exec();
    if (!user) {
      return sendJsonResponse(res, 401, { message: "Invalid credentials" });
    }

    const isValid = await user.validatePassword(password);
    if (!isValid) {
      return sendJsonResponse(res, 401, { message: "Invalid credentials" });
    }

    const token = jwt.sign(
      { sub: user._id.toString(), username: user.username },
      jwtSecret,
      { expiresIn: jwtExpiry }
    );

    return sendJsonResponse(res, 200, { token });
  } catch (err) {
    return sendJsonResponse(res, 500, { message: "Login failed", error: err.message });
  }
};
