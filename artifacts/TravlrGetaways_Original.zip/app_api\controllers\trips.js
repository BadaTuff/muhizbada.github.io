﻿const Trip = require("../models/trip");

const sendJsonResponse = (res, status, content) => {
  res.status(status).json(content);
};

const handleError = (res, err, message) => {
  console.error(message, err);
  sendJsonResponse(res, 500, { message, error: err.message });
};

module.exports.tripsList = async (req, res) => {
  try {
    const trips = await Trip.find().exec();
    sendJsonResponse(res, 200, trips);
  } catch (err) {
    handleError(res, err, "Error fetching trips");
  }
};

module.exports.tripsAddTrip = async (req, res) => {
  try {
    const tripData = {
      code: req.body.code,
      name: req.body.name,
      price: req.body.price,
      nights: req.body.nights,
      img: req.body.img,
      summary: req.body.summary
    };

    const trip = await Trip.create(tripData);
    sendJsonResponse(res, 201, trip);
  } catch (err) {
    if (err.name === "ValidationError") {
      return sendJsonResponse(res, 400, { message: "Trip validation failed", error: err.message });
    }
    handleError(res, err, "Error creating trip");
  }
};

module.exports.tripsFindByCode = async (req, res) => {
  try {
    const trip = await Trip.findOne({ code: req.params.tripCode }).exec();
    if (!trip) {
      return sendJsonResponse(res, 404, { message: "Trip not found" });
    }
    sendJsonResponse(res, 200, trip);
  } catch (err) {
    handleError(res, err, "Error finding trip");
  }
};

module.exports.tripsUpdateTrip = async (req, res) => {
  try {
    const trip = await Trip.findOne({ code: req.params.tripCode }).exec();
    if (!trip) {
      return sendJsonResponse(res, 404, { message: "Trip not found" });
    }

    trip.name = req.body.name || trip.name;
    trip.price = req.body.price || trip.price;
    trip.nights = req.body.nights || trip.nights;
    trip.img = req.body.img || trip.img;
    trip.summary = req.body.summary || trip.summary;

    const updatedTrip = await trip.save();
    sendJsonResponse(res, 200, updatedTrip);
  } catch (err) {
    if (err.name === "ValidationError") {
      return sendJsonResponse(res, 400, { message: "Trip validation failed", error: err.message });
    }
    handleError(res, err, "Error updating trip");
  }
};

module.exports.tripsDeleteTrip = async (req, res) => {
  try {
    const result = await Trip.deleteOne({ code: req.params.tripCode }).exec();
    if (result.deletedCount === 0) {
      return sendJsonResponse(res, 404, { message: "Trip not found" });
    }
    sendJsonResponse(res, 204, null);
  } catch (err) {
    handleError(res, err, "Error deleting trip");
  }
};
