﻿const fs = require("fs");
const path = require("path");

require("../app_api/db");
const Trip = require("../app_api/models/trip");

async function run() {
  try {
    const jsonPath = path.join(__dirname, "..", "data", "trips.json");
    // Read and strip UTF-8 BOM if present
    let raw = fs.readFileSync(jsonPath, "utf8");
    raw = raw.replace(/^\uFEFF/, "");
    const trips = JSON.parse(raw);

    await Trip.deleteMany({});
    const result = await Trip.insertMany(trips);
    console.log(`Seeded ${result.length} trips`);
    process.exit(0);
  } catch (err) {
    console.error("Seed failed:", err.message);
    process.exit(1);
  }
}
run();
