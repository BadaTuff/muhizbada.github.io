﻿const apiBase = process.env.API_BASE || "http://localhost:3000";

const index = (_req, res) => {
  res.render("index", { title: "Travlr Getaways", tagline: "Book trips, manage itineraries, travel happy." });
};

const travelList = async (_req, res) => {
  try {
    const r = await fetch(`${apiBase}/api/trips`);
    if (!r.ok) throw new Error(`API error ${r.status}`);
    const trips = await r.json();
    res.render("travel", {
      title: "Travel",
      intro: "Browse featured trips by destination and price.",
      trips
    });
  } catch (_err) {
    res.status(500).render("travel", {
      title: "Travel",
      intro: "Sorry, we could not load trips right now.",
      trips: []
    });
  }
};

module.exports = { index, travelList };
