﻿export interface Trip {
  code: string;
  name: string;
  price: number;
  nights: number;
  img?: string;
  summary?: string;
  _id?: string;
  createdOn?: string;
}
