package com.example.weightappui;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import org.mindrot.jbcrypt.BCrypt;

/**
 * DatabaseHelper.java
 *
 * Manages local SQLite storage for the WeightApp application.
 * Handles user authentication credentials and weight log entries in separate tables.
 *
 * Security Enhancement (CS 499 Capstone):
 * This class now implements bcrypt password hashing to protect user credentials.
 * Plain text passwords are never stored in the database. Instead, passwords are
 * hashed using the BCrypt algorithm with a cost factor of 12, which provides
 * strong resistance against brute force attacks.
 *
 * @author Original: CS 360 Project
 * @modified CS 499 Capstone - Security Enhancement
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    // Tag for logging database operations and errors
    private static final String TAG = "DatabaseHelper";

    // Database configuration constants
    private static final String DATABASE_NAME = "WeightApp.db";
    // Version incremented to 3 to trigger migration for existing plain text passwords
    private static final int DATABASE_VERSION = 3;

    // BCrypt work factor: 12 provides good security while maintaining reasonable performance
    // Each increment doubles the computation time, so 12 is a solid balance for mobile devices
    private static final int BCRYPT_WORK_FACTOR = 12;

    // Table: Users - stores authentication credentials
    private static final String TABLE_USERS = "users";
    private static final String COL_USERNAME = "username";
    private static final String COL_PASSWORD = "password";

    // Table: Weights - stores user weight log entries
    private static final String TABLE_WEIGHTS = "weights";
    private static final String COL_ID = "id";
    private static final String COL_USER_REF = "username_ref";
    private static final String COL_DATE = "date";
    private static final String COL_WEIGHT = "weight";

    /**
     * Constructor initializes the database helper with application context.
     *
     * @param context The application context used to create or open the database
     */
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    /**
     * Called when the database is created for the first time.
     * Creates the users and weights tables with appropriate schema.
     *
     * @param db The database instance to execute SQL commands on
     */
    @Override
    public void onCreate(SQLiteDatabase db) {
        try {
            // Users table: stores username as primary key and bcrypt-hashed password
            // The password column stores the full bcrypt hash string (60 characters)
            String createUserTable = "CREATE TABLE " + TABLE_USERS + " (" +
                    COL_USERNAME + " TEXT PRIMARY KEY, " +
                    COL_PASSWORD + " TEXT NOT NULL)";
            db.execSQL(createUserTable);

            // Weights table: stores weight entries with foreign key reference to user
            // Each entry has unique ID, user reference, date, and weight value
            String createWeightTable = "CREATE TABLE " + TABLE_WEIGHTS + " (" +
                    COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COL_USER_REF + " TEXT NOT NULL, " +
                    COL_DATE + " TEXT NOT NULL, " +
                    COL_WEIGHT + " TEXT NOT NULL)";
            db.execSQL(createWeightTable);

            Log.i(TAG, "Database tables created successfully");
        } catch (SQLiteException e) {
            Log.e(TAG, "Error creating database tables: " + e.getMessage());
        }
    }

    /**
     * Called when the database needs to be upgraded due to version change.
     * Handles migration from plain text passwords to bcrypt hashed passwords.
     *
     * For production apps, this would include proper data migration logic.
     * Currently preserves existing data structure while supporting new security features.
     *
     * @param db The database instance
     * @param oldVersion The previous database version number
     * @param newVersion The new database version number
     */
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        Log.i(TAG, "Upgrading database from version " + oldVersion + " to " + newVersion);

        // For development: existing users with plain text passwords will need to re-register
        // In a production app, we would implement proper migration with rehashing on next login
        if (oldVersion < 3) {
            // Version 3 introduces bcrypt hashing
            // Existing plain text passwords will fail verification,
            // so users will need to create new accounts
            Log.w(TAG, "Database upgrade: existing users may need to re-register due to password hashing change");
        }
    }

    // ============================================================
    // USER AUTHENTICATION METHODS
    // ============================================================

    /**
     * Registers a new user with bcrypt-hashed password.
     *
     * Security: The plain text password is hashed using BCrypt before storage.
     * The hash includes a randomly generated salt, making each hash unique even
     * for identical passwords. This protects against rainbow table attacks.
     *
     * @param username The unique username for the new account
     * @param password The plain text password to hash and store
     * @return true if user was successfully added, false otherwise
     */
    public boolean addUser(String username, String password) {
        // Validate inputs before processing
        if (username == null || username.trim().isEmpty()) {
            Log.w(TAG, "addUser: Username cannot be null or empty");
            return false;
        }
        if (password == null || password.isEmpty()) {
            Log.w(TAG, "addUser: Password cannot be null or empty");
            return false;
        }

        SQLiteDatabase db = null;
        try {
            db = this.getWritableDatabase();

            // Hash the password using bcrypt with specified work factor
            // BCrypt.gensalt() creates a random salt embedded in the hash
            String hashedPassword = BCrypt.hashpw(password, BCrypt.gensalt(BCRYPT_WORK_FACTOR));

            ContentValues values = new ContentValues();
            values.put(COL_USERNAME, username.trim());
            values.put(COL_PASSWORD, hashedPassword);

            long result = db.insert(TABLE_USERS, null, values);

            if (result != -1) {
                Log.i(TAG, "User registered successfully: " + username);
                return true;
            } else {
                Log.w(TAG, "Failed to register user: " + username);
                return false;
            }
        } catch (SQLiteException e) {
            Log.e(TAG, "Database error during user registration: " + e.getMessage());
            return false;
        } catch (IllegalArgumentException e) {
            // BCrypt can throw this for invalid inputs
            Log.e(TAG, "Password hashing error: " + e.getMessage());
            return false;
        }
    }

    /**
     * Verifies user credentials by comparing provided password against stored hash.
     *
     * Security: Uses BCrypt.checkpw() which performs constant-time comparison
     * to prevent timing attacks. The stored hash contains the salt, so no
     * separate salt storage is needed.
     *
     * @param username The username to authenticate
     * @param password The plain text password to verify
     * @return true if credentials are valid, false otherwise
     */
    public boolean checkUser(String username, String password) {
        // Validate inputs before database query
        if (username == null || username.trim().isEmpty()) {
            Log.w(TAG, "checkUser: Username cannot be null or empty");
            return false;
        }
        if (password == null || password.isEmpty()) {
            Log.w(TAG, "checkUser: Password cannot be null or empty");
            return false;
        }

        SQLiteDatabase db = null;
        Cursor cursor = null;

        try {
            db = this.getReadableDatabase();

            // Retrieve the stored hash for the given username
            // We only query for the password column since we need the hash to verify
            cursor = db.query(TABLE_USERS,
                    new String[]{COL_PASSWORD},
                    COL_USERNAME + "=?",
                    new String[]{username.trim()},
                    null, null, null);

            if (cursor != null && cursor.moveToFirst()) {
                // User exists, retrieve the stored bcrypt hash
                String storedHash = cursor.getString(0);

                // Verify the password against the stored hash
                // BCrypt.checkpw handles salt extraction and comparison securely
                boolean passwordMatch = BCrypt.checkpw(password, storedHash);

                if (passwordMatch) {
                    Log.i(TAG, "User authenticated successfully: " + username);
                } else {
                    Log.w(TAG, "Invalid password attempt for user: " + username);
                }

                return passwordMatch;
            } else {
                Log.w(TAG, "User not found: " + username);
                return false;
            }
        } catch (SQLiteException e) {
            Log.e(TAG, "Database error during authentication: " + e.getMessage());
            return false;
        } catch (IllegalArgumentException e) {
            // BCrypt throws this if stored hash is malformed (legacy plain text password)
            Log.e(TAG, "Password verification error (possible legacy account): " + e.getMessage());
            return false;
        } finally {
            // Always close cursor to prevent memory leaks
            if (cursor != null) {
                cursor.close();
            }
        }
    }

    /**
     * Checks if a username already exists in the database.
     * Used during registration to prevent duplicate accounts.
     *
     * @param username The username to check for existence
     * @return true if username exists, false otherwise
     */
    public boolean checkUserExists(String username) {
        if (username == null || username.trim().isEmpty()) {
            Log.w(TAG, "checkUserExists: Username cannot be null or empty");
            return false;
        }

        SQLiteDatabase db = null;
        Cursor cursor = null;

        try {
            db = this.getReadableDatabase();
            cursor = db.query(TABLE_USERS,
                    new String[]{COL_USERNAME},
                    COL_USERNAME + "=?",
                    new String[]{username.trim()},
                    null, null, null);

            boolean exists = (cursor != null && cursor.getCount() > 0);

            if (exists) {
                Log.d(TAG, "Username already exists: " + username);
            }

            return exists;
        } catch (SQLiteException e) {
            Log.e(TAG, "Database error checking user existence: " + e.getMessage());
            return false;
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }

    // ============================================================
    // WEIGHT LOGGING METHODS
    // ============================================================

    /**
     * Adds a new weight entry for a user.
     *
     * @param username The user who owns this weight entry
     * @param date The date of the weight measurement
     * @param weight The weight value with units
     * @return The row ID of the inserted entry, or -1 if insertion failed
     */
    public long addWeight(String username, String date, String weight) {
        // Input validation
        if (username == null || username.trim().isEmpty()) {
            Log.w(TAG, "addWeight: Username is required");
            return -1;
        }
        if (date == null || date.trim().isEmpty()) {
            Log.w(TAG, "addWeight: Date is required");
            return -1;
        }
        if (weight == null || weight.trim().isEmpty()) {
            Log.w(TAG, "addWeight: Weight is required");
            return -1;
        }

        SQLiteDatabase db = null;
        try {
            db = this.getWritableDatabase();

            ContentValues values = new ContentValues();
            values.put(COL_USER_REF, username.trim());
            values.put(COL_DATE, date.trim());
            values.put(COL_WEIGHT, weight.trim());

            long id = db.insert(TABLE_WEIGHTS, null, values);

            if (id != -1) {
                Log.i(TAG, "Weight entry added for user " + username + ": " + weight + " on " + date);
            } else {
                Log.w(TAG, "Failed to add weight entry");
            }

            return id;
        } catch (SQLiteException e) {
            Log.e(TAG, "Database error adding weight entry: " + e.getMessage());
            return -1;
        }
    }

    /**
     * Retrieves all weight entries for a specific user.
     *
     * Note: The caller is responsible for closing the returned Cursor
     * to prevent memory leaks.
     *
     * @param username The user whose weight entries to retrieve
     * @return Cursor containing weight entries, or null if error occurred
     */
    public Cursor getUserWeights(String username) {
        if (username == null || username.trim().isEmpty()) {
            Log.w(TAG, "getUserWeights: Username is required");
            return null;
        }

        try {
            SQLiteDatabase db = this.getReadableDatabase();
            return db.query(TABLE_WEIGHTS, null,
                    COL_USER_REF + "=?",
                    new String[]{username.trim()},
                    null, null, null);
        } catch (SQLiteException e) {
            Log.e(TAG, "Database error retrieving weights: " + e.getMessage());
            return null;
        }
    }

    /**
     * Updates an existing weight entry.
     *
     * @param id The unique ID of the weight entry to update
     * @param date The new date value
     * @param weight The new weight value
     * @return true if update was successful, false otherwise
     */
    public boolean updateWeight(long id, String date, String weight) {
        // Validate inputs
        if (id <= 0) {
            Log.w(TAG, "updateWeight: Invalid ID");
            return false;
        }
        if (date == null || date.trim().isEmpty()) {
            Log.w(TAG, "updateWeight: Date is required");
            return false;
        }
        if (weight == null || weight.trim().isEmpty()) {
            Log.w(TAG, "updateWeight: Weight is required");
            return false;
        }

        SQLiteDatabase db = null;
        try {
            db = this.getWritableDatabase();

            ContentValues values = new ContentValues();
            values.put(COL_DATE, date.trim());
            values.put(COL_WEIGHT, weight.trim());

            int rows = db.update(TABLE_WEIGHTS, values,
                    COL_ID + " = ?",
                    new String[]{String.valueOf(id)});

            if (rows > 0) {
                Log.i(TAG, "Weight entry " + id + " updated successfully");
                return true;
            } else {
                Log.w(TAG, "No weight entry found with ID: " + id);
                return false;
            }
        } catch (SQLiteException e) {
            Log.e(TAG, "Database error updating weight entry: " + e.getMessage());
            return false;
        }
    }

    /**
     * Deletes a weight entry by ID.
     *
     * @param id The unique ID of the weight entry to delete
     * @return true if deletion was successful, false otherwise
     */
    public boolean deleteWeight(long id) {
        if (id <= 0) {
            Log.w(TAG, "deleteWeight: Invalid ID");
            return false;
        }

        SQLiteDatabase db = null;
        try {
            db = this.getWritableDatabase();
            int rows = db.delete(TABLE_WEIGHTS,
                    COL_ID + " = ?",
                    new String[]{String.valueOf(id)});

            if (rows > 0) {
                Log.i(TAG, "Weight entry " + id + " deleted successfully");
                return true;
            } else {
                Log.w(TAG, "No weight entry found with ID: " + id);
                return false;
            }
        } catch (SQLiteException e) {
            Log.e(TAG, "Database error deleting weight entry: " + e.getMessage());
            return false;
        }
    }
}
