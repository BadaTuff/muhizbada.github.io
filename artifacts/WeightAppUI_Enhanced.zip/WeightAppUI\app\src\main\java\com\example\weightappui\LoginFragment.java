package com.example.weightappui;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import java.util.regex.Pattern;

/**
 * LoginFragment.java
 *
 * Handles user login and account creation interactions for the WeightApp.
 * Connects to SQLite via DatabaseHelper to verify credentials or store new ones.
 *
 * Security Enhancement (CS 499 Capstone):
 * This fragment now implements comprehensive input validation including:
 * - Username format validation (alphanumeric, minimum length)
 * - Password strength requirements (length, complexity)
 * - Proper error handling with user-friendly messages
 *
 * @author Original: CS 360 Project
 * @modified CS 499 Capstone - Input Validation Enhancement
 */
public class LoginFragment extends Fragment {

    // Tag for logging authentication events
    private static final String TAG = "LoginFragment";

    // Database helper instance for authentication operations
    private DatabaseHelper dbHelper;

    // ============================================================
    // VALIDATION CONSTANTS
    // ============================================================

    // Username validation: minimum 3 characters, alphanumeric and underscores only
    private static final int MIN_USERNAME_LENGTH = 3;
    private static final int MAX_USERNAME_LENGTH = 30;
    private static final Pattern USERNAME_PATTERN = Pattern.compile("^[a-zA-Z0-9_]+$");

    // Password validation: minimum 8 characters with complexity requirements
    private static final int MIN_PASSWORD_LENGTH = 8;
    private static final int MAX_PASSWORD_LENGTH = 128;

    // Password complexity patterns
    private static final Pattern HAS_UPPERCASE = Pattern.compile("[A-Z]");
    private static final Pattern HAS_LOWERCASE = Pattern.compile("[a-z]");
    private static final Pattern HAS_DIGIT = Pattern.compile("[0-9]");
    private static final Pattern HAS_SPECIAL = Pattern.compile("[!@#$%^&*(),.?\":{}|<>]");

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_login, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        try {
            dbHelper = new DatabaseHelper(requireContext());
        } catch (Exception e) {
            Log.e(TAG, "Failed to initialize database helper: " + e.getMessage());
            Toast.makeText(getContext(), "Error initializing app. Please restart.", Toast.LENGTH_LONG).show();
            return;
        }

        EditText inputEmail = view.findViewById(R.id.inputEmail);
        EditText inputPassword = view.findViewById(R.id.inputPassword);

        // Login button handler with validation
        view.findViewById(R.id.btnLogin).setOnClickListener(v -> handleLogin(v, inputEmail, inputPassword));

        // Create account button handler with validation
        view.findViewById(R.id.btnCreate).setOnClickListener(v -> handleCreateAccount(v, inputEmail, inputPassword));
    }

    /**
     * Handles user login with input validation and error handling.
     *
     * @param view The clicked view for navigation
     * @param inputEmail The username input field
     * @param inputPassword The password input field
     */
    private void handleLogin(View view, EditText inputEmail, EditText inputPassword) {
        String username = inputEmail.getText().toString().trim();
        String password = inputPassword.getText().toString();

        // Basic empty field validation for login
        if (username.isEmpty()) {
            inputEmail.setError("Username is required");
            inputEmail.requestFocus();
            return;
        }

        if (password.isEmpty()) {
            inputPassword.setError("Password is required");
            inputPassword.requestFocus();
            return;
        }

        try {
            // Attempt authentication with entered credentials
            if (dbHelper.checkUser(username, password)) {
                Log.i(TAG, "Login successful for user: " + username);

                // Clear sensitive data from input fields
                inputPassword.getText().clear();

                // Navigate to main grid with username context
                Bundle args = new Bundle();
                args.putString("username", username);
                Navigation.findNavController(view).navigate(R.id.action_login_to_grid, args);
            } else {
                // Generic error message to prevent username enumeration attacks
                Log.w(TAG, "Failed login attempt for user: " + username);
                Toast.makeText(getContext(), "Invalid username or password", Toast.LENGTH_SHORT).show();
                inputPassword.getText().clear();
                inputPassword.requestFocus();
            }
        } catch (Exception e) {
            Log.e(TAG, "Error during login: " + e.getMessage());
            Toast.makeText(getContext(), "Login failed. Please try again.", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Handles new account creation with comprehensive validation.
     *
     * @param view The clicked view for navigation
     * @param inputEmail The username input field
     * @param inputPassword The password input field
     */
    private void handleCreateAccount(View view, EditText inputEmail, EditText inputPassword) {
        String username = inputEmail.getText().toString().trim();
        String password = inputPassword.getText().toString();

        // Validate username format and requirements
        String usernameError = validateUsername(username);
        if (usernameError != null) {
            inputEmail.setError(usernameError);
            inputEmail.requestFocus();
            return;
        }

        // Validate password strength requirements
        String passwordError = validatePassword(password);
        if (passwordError != null) {
            inputPassword.setError(passwordError);
            inputPassword.requestFocus();
            return;
        }

        try {
            // Check if username already exists
            if (dbHelper.checkUserExists(username)) {
                inputEmail.setError("Username is already taken");
                inputEmail.requestFocus();
                Log.w(TAG, "Registration attempted with existing username: " + username);
                return;
            }

            // Attempt to create the new user account
            if (dbHelper.addUser(username, password)) {
                Log.i(TAG, "Account created successfully for user: " + username);
                Toast.makeText(getContext(), "Account created successfully!", Toast.LENGTH_SHORT).show();

                // Clear sensitive data
                inputPassword.getText().clear();

                // Navigate to main grid
                Bundle args = new Bundle();
                args.putString("username", username);
                Navigation.findNavController(view).navigate(R.id.action_login_to_grid, args);
            } else {
                Log.e(TAG, "Failed to create account for user: " + username);
                Toast.makeText(getContext(), "Registration failed. Please try again.", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Log.e(TAG, "Error during registration: " + e.getMessage());
            Toast.makeText(getContext(), "Registration failed. Please try again.", Toast.LENGTH_SHORT).show();
        }
    }

    // ============================================================
    // INPUT VALIDATION METHODS
    // ============================================================

    /**
     * Validates username format and requirements.
     *
     * Requirements:
     * - 3 to 30 characters in length
     * - Contains only letters, numbers, and underscores
     * - Cannot be empty or whitespace only
     *
     * @param username The username to validate
     * @return Error message if invalid, null if valid
     */
    private String validateUsername(String username) {
        if (username == null || username.isEmpty()) {
            return "Username is required";
        }

        if (username.length() < MIN_USERNAME_LENGTH) {
            return "Username must be at least " + MIN_USERNAME_LENGTH + " characters";
        }

        if (username.length() > MAX_USERNAME_LENGTH) {
            return "Username cannot exceed " + MAX_USERNAME_LENGTH + " characters";
        }

        if (!USERNAME_PATTERN.matcher(username).matches()) {
            return "Username can only contain letters, numbers, and underscores";
        }

        return null; // Valid
    }

    /**
     * Validates password strength requirements.
     *
     * Requirements:
     * - Minimum 8 characters in length
     * - Maximum 128 characters (reasonable limit)
     * - Contains at least one uppercase letter
     * - Contains at least one lowercase letter
     * - Contains at least one digit
     * - Contains at least one special character
     *
     * These requirements follow NIST guidelines for password complexity
     * while remaining practical for mobile users.
     *
     * @param password The password to validate
     * @return Error message if invalid, null if valid
     */
    private String validatePassword(String password) {
        if (password == null || password.isEmpty()) {
            return "Password is required";
        }

        if (password.length() < MIN_PASSWORD_LENGTH) {
            return "Password must be at least " + MIN_PASSWORD_LENGTH + " characters";
        }

        if (password.length() > MAX_PASSWORD_LENGTH) {
            return "Password is too long";
        }

        // Build a detailed error message showing which requirements are missing
        StringBuilder missingRequirements = new StringBuilder();

        if (!HAS_UPPERCASE.matcher(password).find()) {
            missingRequirements.append("uppercase letter, ");
        }

        if (!HAS_LOWERCASE.matcher(password).find()) {
            missingRequirements.append("lowercase letter, ");
        }

        if (!HAS_DIGIT.matcher(password).find()) {
            missingRequirements.append("number, ");
        }

        if (!HAS_SPECIAL.matcher(password).find()) {
            missingRequirements.append("special character (!@#$%^&*), ");
        }

        if (missingRequirements.length() > 0) {
            // Remove trailing comma and space
            String missing = missingRequirements.substring(0, missingRequirements.length() - 2);
            return "Password must include: " + missing;
        }

        return null; // Valid
    }
}
