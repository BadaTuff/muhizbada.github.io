package com.example.weightappui;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

// Handles SMS permission logic and sending real notifications.
// Key requirement: Check permission first, then enable features.
public class SmsFragment extends Fragment {

    private TextView status;
    private Button btnSimulate;

    // Using the modern ActivityResult API for permissions.
    // This callback runs immediately after the user taps Allow or Deny.
    private final ActivityResultLauncher<String> requestPerm = registerForActivityResult(
            new ActivityResultContracts.RequestPermission(),
            granted -> {
                updateStatusUI(granted);
            }
    );

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_sms, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        status = view.findViewById(R.id.txtSmsStatus);
        btnSimulate = view.findViewById(R.id.btnSimulate);

        // Allow manual re-check if the user changes settings outside the app.
        view.findViewById(R.id.btnCheck).setOnClickListener(v -> checkPermission());

        // Launch the system permission dialog.
        view.findViewById(R.id.btnRequest).setOnClickListener(v ->
                requestPerm.launch(Manifest.permission.SEND_SMS)
        );

        // Sends a real SMS if permission is granted, otherwise shows a toast.
        // We use a dummy number "5556" which works on the Android Emulator to text itself.
        btnSimulate.setOnClickListener(v -> sendSmsNotification());

        // Initial state check on load.
        checkPermission();
    }

    private void checkPermission() {
        boolean granted = ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;
        updateStatusUI(granted);
    }

    private void updateStatusUI(boolean granted) {
        if (status != null) {
            status.setText(granted ? "SMS permission status: Granted" : "SMS permission status: Not granted");
        }
        if (btnSimulate != null) {
            btnSimulate.setEnabled(granted);
        }
    }

    private void sendSmsNotification() {
        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            try {
                // "5556" is the standard port loopback number for emulator instance 1.
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage("5556", null, "Goal Reached! You hit your target weight.", null, null);
                Toast.makeText(requireContext(), "SMS Sent!", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(requireContext(), "Failed to send SMS.", Toast.LENGTH_SHORT).show();
                e.printStackTrace();
            }
        } else {
            Toast.makeText(requireContext(), "Permission denied. Cannot send SMS.", Toast.LENGTH_SHORT).show();
        }
    }
}
