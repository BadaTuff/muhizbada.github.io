package com.example.weightappui;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.InputType;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

/**
 * GridFragment.java
 *
 * The main hub for viewing and managing weight entries in the WeightApp.
 * Handles list display, CRUD operations, and goal-triggered SMS notifications.
 *
 * Enhancement (CS 499 Capstone):
 * This fragment now includes comprehensive input validation for weight entries:
 * - Date format validation (MM/dd/yyyy) with reasonable date range checks
 * - Weight value validation (positive numbers within realistic range)
 * - Goal weight validation
 * - Improved error handling with user-friendly messages
 * - Comprehensive code documentation
 *
 * @author Original: CS 360 Project
 * @modified CS 499 Capstone - Input Validation and Error Handling Enhancement
 */
public class GridFragment extends Fragment {

    // Tag for logging weight management events
    private static final String TAG = "GridFragment";

    // Data structures for weight list management
    private final List<WeightRow> weightList = new ArrayList<>();
    private WeightAdapter adapter;
    private DatabaseHelper dbHelper;
    private String currentUsername;

    // SharedPreferences key for storing user goal weight
    // Stored in Prefs rather than DB since it's just one value per user
    private static final String PREFS_GOAL = "goal_prefs";

    // State tracking for edit mode vs. create mode
    private long selectedId = -1;
    private int selectedPosition = -1;

    // ============================================================
    // VALIDATION CONSTANTS
    // ============================================================

    // Weight validation: reasonable range for human body weight in pounds
    private static final double MIN_WEIGHT_LBS = 1.0;
    private static final double MAX_WEIGHT_LBS = 1500.0;  // Covers extreme cases

    // Date validation: accepted format and reasonable range
    private static final String DATE_FORMAT = "MM/dd/yyyy";
    private static final Pattern DATE_PATTERN = Pattern.compile("^\\d{1,2}/\\d{1,2}/\\d{4}$");

    // Date range: no entries before year 2000 or more than 1 year in the future
    private static final int MIN_YEAR = 2000;
    private static final int MAX_FUTURE_DAYS = 365;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_grid, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Retrieve username passed from login screen
        if (getArguments() != null) {
            currentUsername = getArguments().getString("username");
        }

        // Validate that we have a valid user context
        if (currentUsername == null || currentUsername.isEmpty()) {
            Log.e(TAG, "No username provided, returning to login");
            Toast.makeText(getContext(), "Session error. Please log in again.", Toast.LENGTH_SHORT).show();
            Navigation.findNavController(view).navigate(R.id.action_grid_to_login);
            return;
        }

        try {
            dbHelper = new DatabaseHelper(requireContext());
        } catch (Exception e) {
            Log.e(TAG, "Failed to initialize database: " + e.getMessage());
            Toast.makeText(getContext(), "Database error. Please restart the app.", Toast.LENGTH_LONG).show();
            return;
        }

        // Initialize UI components
        EditText inputDate = view.findViewById(R.id.inputDate);
        EditText inputWeight = view.findViewById(R.id.inputWeight);
        Button btnAction = view.findViewById(R.id.btnAdd);

        // Set up goal button
        view.findViewById(R.id.btnSetGoal).setOnClickListener(v -> showSetGoalDialog());

        // Load existing weight data from database
        loadDataFromDb();

        // Configure RecyclerView for weight list display
        RecyclerView recycler = view.findViewById(R.id.recycler);

        adapter = new WeightAdapter(weightList, new WeightAdapter.OnItemClickListener() {
            @Override
            public void onDelete(long id, int position) {
                handleDeleteWeight(id, position, inputDate, inputWeight, btnAction);
            }

            @Override
            public void onEdit(WeightRow row, int position) {
                // Populate form fields for editing
                inputDate.setText(row.getDate());
                inputWeight.setText(row.getWeight().replace(" lb", ""));
                selectedId = row.getId();
                selectedPosition = position;
                btnAction.setText("Update");
            }
        });

        recycler.setLayoutManager(new LinearLayoutManager(getContext()));
        recycler.setAdapter(adapter);

        // Single button handles both Add and Update based on current state
        btnAction.setOnClickListener(v -> handleAddOrUpdate(inputDate, inputWeight, btnAction));

        // Logout button returns to login screen
        view.findViewById(R.id.btnLogout).setOnClickListener(v -> {
            Log.i(TAG, "User logged out: " + currentUsername);
            Navigation.findNavController(v).navigate(R.id.action_grid_to_login);
        });
    }

    /**
     * Handles the add or update action for weight entries.
     * Validates input before persisting to database.
     *
     * @param inputDate The date input field
     * @param inputWeight The weight input field
     * @param btnAction The action button (shows Add or Update)
     */
    private void handleAddOrUpdate(EditText inputDate, EditText inputWeight, Button btnAction) {
        String dateStr = inputDate.getText().toString().trim();
        String weightStr = inputWeight.getText().toString().trim();

        // Validate date input
        String dateError = validateDate(dateStr);
        if (dateError != null) {
            inputDate.setError(dateError);
            inputDate.requestFocus();
            return;
        }

        // Validate weight input
        String weightError = validateWeight(weightStr);
        if (weightError != null) {
            inputWeight.setError(weightError);
            inputWeight.requestFocus();
            return;
        }

        try {
            // Format weight consistently with units
            String formattedWeight = formatWeight(weightStr);

            if (selectedId == -1) {
                // Creating a new entry
                long id = dbHelper.addWeight(currentUsername, dateStr, formattedWeight);
                if (id != -1) {
                    weightList.add(new WeightRow(id, dateStr, formattedWeight));
                    adapter.notifyItemInserted(weightList.size() - 1);
                    Log.i(TAG, "Weight entry added: " + formattedWeight + " on " + dateStr);
                    checkGoalAndNotify(weightStr);
                } else {
                    Toast.makeText(getContext(), "Failed to save weight entry", Toast.LENGTH_SHORT).show();
                    Log.e(TAG, "Database insert failed for weight entry");
                }
            } else {
                // Updating an existing entry
                if (dbHelper.updateWeight(selectedId, dateStr, formattedWeight)) {
                    WeightRow row = weightList.get(selectedPosition);
                    row.setDate(dateStr);
                    row.setWeight(formattedWeight);
                    adapter.notifyItemChanged(selectedPosition);
                    Log.i(TAG, "Weight entry updated: ID=" + selectedId);
                    checkGoalAndNotify(weightStr);
                } else {
                    Toast.makeText(getContext(), "Failed to update weight entry", Toast.LENGTH_SHORT).show();
                    Log.e(TAG, "Database update failed for weight entry ID: " + selectedId);
                }
            }
            resetForm(inputDate, inputWeight, btnAction);
        } catch (Exception e) {
            Log.e(TAG, "Error saving weight entry: " + e.getMessage());
            Toast.makeText(getContext(), "Error saving entry. Please try again.", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Handles deletion of a weight entry with confirmation.
     *
     * @param id The database ID of the entry to delete
     * @param position The position in the list
     * @param inputDate Date input field to reset
     * @param inputWeight Weight input field to reset
     * @param btnAction Action button to reset
     */
    private void handleDeleteWeight(long id, int position, EditText inputDate,
                                    EditText inputWeight, Button btnAction) {
        try {
            dbHelper.deleteWeight(id);
            weightList.remove(position);
            adapter.notifyItemRemoved(position);
            resetForm(inputDate, inputWeight, btnAction);
            Log.i(TAG, "Weight entry deleted: ID=" + id);
        } catch (Exception e) {
            Log.e(TAG, "Error deleting weight entry: " + e.getMessage());
            Toast.makeText(getContext(), "Failed to delete entry", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Displays dialog for setting goal weight with validation.
     * Saves to SharedPreferences keyed by username for user isolation.
     * Uses custom button handling to prevent dialog dismissal on validation failure.
     */
    private void showSetGoalDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
        builder.setTitle("Set Goal Weight");

        final EditText input = new EditText(requireContext());
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);

        // Load current goal if one exists
        SharedPreferences prefs = requireContext().getSharedPreferences(PREFS_GOAL, Context.MODE_PRIVATE);
        String currentGoal = prefs.getString(currentUsername, "");

        if (!currentGoal.isEmpty()) {
            input.setText(currentGoal);
        } else {
            input.setHint("e.g. 150");
        }

        builder.setView(input);

        // Set buttons with null listeners initially - we'll override after showing
        builder.setPositiveButton("Save", null);
        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());

        // Create and show the dialog
        AlertDialog dialog = builder.create();
        dialog.show();

        // Override the positive button to prevent auto-dismiss on validation failure
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String goalValue = input.getText().toString().trim();

            // Validate goal weight
            String goalError = validateWeight(goalValue);
            if (goalError != null) {
                // Show error but keep dialog open
                input.setError(goalError);
                Toast.makeText(getContext(), goalError, Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                prefs.edit().putString(currentUsername, goalValue).apply();
                Toast.makeText(getContext(), "Goal set to " + goalValue + " lbs", Toast.LENGTH_SHORT).show();
                Log.i(TAG, "Goal weight set: " + goalValue + " lbs for user " + currentUsername);
                dialog.dismiss(); // Only dismiss on success
            } catch (Exception e) {
                Log.e(TAG, "Error saving goal: " + e.getMessage());
                Toast.makeText(getContext(), "Failed to save goal", Toast.LENGTH_SHORT).show();
            }
        });
    }

    /**
     * Checks if the recorded weight meets the goal and sends SMS notification if permitted.
     * Only triggers for weight loss goals (current weight at or below goal).
     *
     * @param weightStr The newly recorded weight value
     */
    private void checkGoalAndNotify(String weightStr) {
        SharedPreferences prefs = requireContext().getSharedPreferences(PREFS_GOAL, Context.MODE_PRIVATE);
        String goalStr = prefs.getString(currentUsername, null);

        if (goalStr == null || goalStr.isEmpty()) {
            return; // No goal set
        }

        try {
            // Parse weight values, stripping units if present
            double currentWeight = parseWeightValue(weightStr);
            double goalWeight = Double.parseDouble(goalStr);

            // Trigger notification if current weight is at or below goal (weight loss context)
            if (currentWeight <= goalWeight) {
                if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.SEND_SMS)
                        == PackageManager.PERMISSION_GRANTED) {

                    // Port 5556 is the loopback for Android Emulator testing
                    SmsManager smsManager = SmsManager.getDefault();
                    smsManager.sendTextMessage("5556", null,
                            "Congrats! You hit your goal of " + goalWeight + " lbs!", null, null);

                    Toast.makeText(getContext(), "Goal reached! SMS sent.", Toast.LENGTH_SHORT).show();
                    Log.i(TAG, "Goal reached, SMS notification sent");
                } else {
                    // Graceful fallback if SMS permission not granted
                    Toast.makeText(getContext(), "Goal reached! (Enable SMS for alerts)", Toast.LENGTH_SHORT).show();
                    Log.i(TAG, "Goal reached, but SMS permission not granted");
                }
            }
        } catch (NumberFormatException e) {
            Log.w(TAG, "Could not parse weight for goal comparison: " + e.getMessage());
        }
    }

    /**
     * Resets the form to its initial state for new entry.
     *
     * @param date Date input field
     * @param weight Weight input field
     * @param btn Action button
     */
    private void resetForm(EditText date, EditText weight, Button btn) {
        date.getText().clear();
        date.setError(null);
        weight.getText().clear();
        weight.setError(null);
        btn.setText("Add");
        selectedId = -1;
        selectedPosition = -1;
    }

    /**
     * Loads weight entries from database for the current user.
     * Called on fragment creation to populate the list.
     */
    private void loadDataFromDb() {
        weightList.clear();
        Cursor cursor = null;

        try {
            cursor = dbHelper.getUserWeights(currentUsername);
            if (cursor != null && cursor.moveToFirst()) {
                do {
                    // Column indices: ID=0, username_ref=1, DATE=2, WEIGHT=3
                    long id = cursor.getLong(0);
                    String date = cursor.getString(2);
                    String weight = cursor.getString(3);
                    weightList.add(new WeightRow(id, date, weight));
                } while (cursor.moveToNext());
                Log.i(TAG, "Loaded " + weightList.size() + " weight entries for user " + currentUsername);
            }
        } catch (Exception e) {
            Log.e(TAG, "Error loading weight data: " + e.getMessage());
            Toast.makeText(getContext(), "Error loading data", Toast.LENGTH_SHORT).show();
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }

    // ============================================================
    // INPUT VALIDATION METHODS
    // ============================================================

    /**
     * Validates date input for weight entries.
     *
     * Requirements:
     * - Format must be MM/dd/yyyy
     * - Date must be a valid calendar date
     * - Year must be 2000 or later
     * - Date cannot be more than 1 year in the future
     *
     * @param dateStr The date string to validate
     * @return Error message if invalid, null if valid
     */
    private String validateDate(String dateStr) {
        if (dateStr == null || dateStr.isEmpty()) {
            return "Date is required";
        }

        // Check basic format pattern
        if (!DATE_PATTERN.matcher(dateStr).matches()) {
            return "Use format MM/dd/yyyy";
        }

        // Parse and validate actual date
        SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT, Locale.US);
        sdf.setLenient(false); // Strict parsing (no Feb 30, etc.)

        try {
            Date parsedDate = sdf.parse(dateStr);
            if (parsedDate == null) {
                return "Invalid date";
            }

            Calendar cal = Calendar.getInstance();
            cal.setTime(parsedDate);
            int year = cal.get(Calendar.YEAR);

            // Check minimum year
            if (year < MIN_YEAR) {
                return "Year must be " + MIN_YEAR + " or later";
            }

            // Check not too far in the future
            Calendar maxFuture = Calendar.getInstance();
            maxFuture.add(Calendar.DAY_OF_YEAR, MAX_FUTURE_DAYS);

            if (parsedDate.after(maxFuture.getTime())) {
                return "Date cannot be more than 1 year in the future";
            }

        } catch (ParseException e) {
            return "Invalid date. Use format MM/dd/yyyy";
        }

        return null; // Valid
    }

    /**
     * Validates weight input for weight entries.
     *
     * Requirements:
     * - Must be a valid positive number
     * - Must be within reasonable range (1 to 1500 lbs)
     * - Can optionally include "lb" suffix
     *
     * @param weightStr The weight string to validate
     * @return Error message if invalid, null if valid
     */
    private String validateWeight(String weightStr) {
        if (weightStr == null || weightStr.isEmpty()) {
            return "Weight is required";
        }

        try {
            double weight = parseWeightValue(weightStr);

            if (weight <= 0) {
                return "Weight must be a positive number";
            }

            if (weight < MIN_WEIGHT_LBS) {
                return "Weight must be at least " + MIN_WEIGHT_LBS + " lb";
            }

            if (weight > MAX_WEIGHT_LBS) {
                return "Weight cannot exceed " + MAX_WEIGHT_LBS + " lbs";
            }

        } catch (NumberFormatException e) {
            return "Enter a valid number";
        }

        return null; // Valid
    }

    /**
     * Parses weight value from string, handling optional "lb" suffix.
     *
     * @param weightStr The weight string to parse
     * @return The numeric weight value
     * @throws NumberFormatException if value cannot be parsed
     */
    private double parseWeightValue(String weightStr) throws NumberFormatException {
        String cleaned = weightStr.toLowerCase()
                .replace("lb", "")
                .replace("lbs", "")
                .trim();
        return Double.parseDouble(cleaned);
    }

    /**
     * Formats weight value with consistent units.
     *
     * @param weightStr The weight value to format
     * @return Formatted weight string with "lb" suffix
     */
    private String formatWeight(String weightStr) {
        String cleaned = weightStr.toLowerCase()
                .replace("lb", "")
                .replace("lbs", "")
                .trim();
        return cleaned + " lb";
    }
}
