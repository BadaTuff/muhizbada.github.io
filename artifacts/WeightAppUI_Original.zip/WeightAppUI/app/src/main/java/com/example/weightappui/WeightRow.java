package com.example.weightappui;

// Simple container for our grid rows.
// Now includes a database ID to support reliable deletion and updates.
public class WeightRow {
    private long id;
    private String date;
    private String weight;

    public WeightRow(long id, String date, String weight) {
        this.id = id;
        this.date = date;
        this.weight = weight;
    }

    public long getId() { return id; }
    
    public String getDate() { return date; }
    public void setDate(String date) { this.date = date; }

    public String getWeight() { return weight; }
    public void setWeight(String weight) { this.weight = weight; }
}
