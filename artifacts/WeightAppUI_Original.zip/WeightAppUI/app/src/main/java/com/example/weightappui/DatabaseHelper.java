package com.example.weightappui;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

// Manages local SQLite storage.
// Handles user creds and weight logs in separate tables.
public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "WeightApp.db";
    private static final int DATABASE_VERSION = 2;

    // Table: Users
    private static final String TABLE_USERS = "users";
    private static final String COL_USERNAME = "username";
    private static final String COL_PASSWORD = "password";

    // Table: Weights
    private static final String TABLE_WEIGHTS = "weights";
    private static final String COL_ID = "id";
    private static final String COL_USER_REF = "username_ref";
    private static final String COL_DATE = "date";
    private static final String COL_WEIGHT = "weight";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Basic auth table. In a real app, we'd hash these passwords.
        String createUserTable = "CREATE TABLE " + TABLE_USERS + " (" +
                COL_USERNAME + " TEXT PRIMARY KEY, " +
                COL_PASSWORD + " TEXT)";
        db.execSQL(createUserTable);

        // Weight log with a foreign key concept for the user reference.
        String createWeightTable = "CREATE TABLE " + TABLE_WEIGHTS + " (" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_USER_REF + " TEXT, " +
                COL_DATE + " TEXT, " +
                COL_WEIGHT + " TEXT)";
        db.execSQL(createWeightTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Only drop if we are okay losing data (dev mode).
        // For now, we'll leave data intact to prevent accidental wipes during testing.
        // If schema changes, we'd do ALTER TABLE here.
    }

    // --- User Auth ---

    public boolean addUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_USERNAME, username);
        values.put(COL_PASSWORD, password);

        long result = db.insert(TABLE_USERS, null, values);
        return result != -1;
    }

    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        // Parametrized to block basic injection attempts.
        Cursor cursor = db.query(TABLE_USERS, new String[]{COL_USERNAME},
                COL_USERNAME + "=? AND " + COL_PASSWORD + "=?",
                new String[]{username, password}, null, null, null);

        boolean exists = (cursor.getCount() > 0);
        cursor.close();
        return exists;
    }

    public boolean checkUserExists(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS, new String[]{COL_USERNAME},
                COL_USERNAME + "=?",
                new String[]{username}, null, null, null);

        boolean exists = (cursor.getCount() > 0);
        cursor.close();
        return exists;
    }

    // --- Weight Logging ---

    public long addWeight(String username, String date, String weight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_USER_REF, username);
        values.put(COL_DATE, date);
        values.put(COL_WEIGHT, weight);
        return db.insert(TABLE_WEIGHTS, null, values);
    }

    public Cursor getUserWeights(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TABLE_WEIGHTS, null,
                COL_USER_REF + "=?",
                new String[]{username}, null, null, null);
    }

    public boolean updateWeight(long id, String date, String weight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_DATE, date);
        values.put(COL_WEIGHT, weight);
        
        // Ensure we only update the specific row ID.
        int rows = db.update(TABLE_WEIGHTS, values, COL_ID + " = ?", new String[]{String.valueOf(id)});
        return rows > 0;
    }

    public void deleteWeight(long id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_WEIGHTS, COL_ID + " = ?", new String[]{String.valueOf(id)});
    }
}
