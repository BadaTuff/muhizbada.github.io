package com.example.weightappui;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

// Standard adapter for the weight grid.
// Connects the data list to the UI. Handles clicks for both 'Edit' (row click) and 'Delete' (button click).
public class WeightAdapter extends RecyclerView.Adapter<WeightAdapter.VH> {

    private final List<WeightRow> rows;
    private final OnItemClickListener listener;

    // Interface to handle both edit (row click) and delete actions.
    public interface OnItemClickListener {
        void onDelete(long id, int position);
        void onEdit(WeightRow row, int position);
    }

    public WeightAdapter(List<WeightRow> rows, OnItemClickListener listener) {
        this.rows = rows;
        this.listener = listener;
    }

    public static class VH extends RecyclerView.ViewHolder {
        public final TextView date;
        public final TextView weight;
        public final ImageButton delete;

        public VH(View v) {
            super(v);
            date = v.findViewById(R.id.txtDate);
            weight = v.findViewById(R.id.txtWeight);
            delete = v.findViewById(R.id.btnDelete);
        }
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate the row layout; relying on XML for spacing/padding to keep this clean.
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_weight_row, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH holder, int position) {
        WeightRow row = rows.get(position);
        holder.date.setText(row.getDate());
        holder.weight.setText(row.getWeight());
        
        // Clicking the trash icon triggers deletion.
        holder.delete.setOnClickListener(v -> {
            int p = holder.getBindingAdapterPosition();
            if (p != RecyclerView.NO_POSITION) {
                listener.onDelete(row.getId(), p);
            }
        });

        // Clicking the row itself triggers the edit flow.
        holder.itemView.setOnClickListener(v -> {
            int p = holder.getBindingAdapterPosition();
            if (p != RecyclerView.NO_POSITION) {
                listener.onEdit(row, p);
            }
        });
    }

    @Override
    public int getItemCount() {
        return rows.size();
    }
}
