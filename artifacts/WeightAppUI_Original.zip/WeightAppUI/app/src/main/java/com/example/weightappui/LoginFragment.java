package com.example.weightappui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

// Handles user login and account creation interactions.
// Connects to SQLite to verify credentials or store new ones.
public class LoginFragment extends Fragment {

    private DatabaseHelper dbHelper;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_login, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        dbHelper = new DatabaseHelper(requireContext());
        
        EditText inputEmail = view.findViewById(R.id.inputEmail);
        EditText inputPassword = view.findViewById(R.id.inputPassword);

        // Logic for logging in an existing user
        view.findViewById(R.id.btnLogin).setOnClickListener(v -> {
            String user = inputEmail.getText().toString().trim();
            String pass = inputPassword.getText().toString().trim();
            
            if (user.isEmpty() || pass.isEmpty()) {
                Toast.makeText(getContext(), "Please fill in all fields", Toast.LENGTH_SHORT).show();
            } else {
                if (dbHelper.checkUser(user, pass)) {
                    // Pass the username to the next screen so we know whose data to load
                    Bundle args = new Bundle();
                    args.putString("username", user);
                    Navigation.findNavController(v).navigate(R.id.action_login_to_grid, args);
                } else {
                    Toast.makeText(getContext(), "Invalid Credentials", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Logic for creating a new user
        view.findViewById(R.id.btnCreate).setOnClickListener(v -> {
            String user = inputEmail.getText().toString().trim();
            String pass = inputPassword.getText().toString().trim();
            
            if (!user.isEmpty() && !pass.isEmpty()) {
                if (dbHelper.checkUserExists(user)) {
                    Toast.makeText(getContext(), "User already exists", Toast.LENGTH_SHORT).show();
                } else {
                    if (dbHelper.addUser(user, pass)) {
                        Toast.makeText(getContext(), "Account Created", Toast.LENGTH_SHORT).show();
                        // Pass username here too so they don't have to log in immediately after creating
                        Bundle args = new Bundle();
                        args.putString("username", user);
                        Navigation.findNavController(v).navigate(R.id.action_login_to_grid, args);
                    } else {
                        Toast.makeText(getContext(), "Registration Failed", Toast.LENGTH_SHORT).show();
                    }
                }
            } else {
                Toast.makeText(getContext(), "Please fill in all fields", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
