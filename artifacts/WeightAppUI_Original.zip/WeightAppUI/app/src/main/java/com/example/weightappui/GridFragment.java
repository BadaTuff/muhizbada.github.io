package com.example.weightappui;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

// The main hub for viewing and adding weights.
// Handles list display, CRUD actions, and goal-triggered SMS alerts.
public class GridFragment extends Fragment {

    private final List<WeightRow> weightList = new ArrayList<>();
    private WeightAdapter adapter;
    private DatabaseHelper dbHelper;
    private String currentUsername;

    // We store the goal in Prefs rather than a full DB table since it's just one value per user.
    private static final String PREFS_GOAL = "goal_prefs";

    // State for editing an existing row versus creating a new one.
    private long selectedId = -1;
    private int selectedPosition = -1;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_grid, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        if (getArguments() != null) {
            currentUsername = getArguments().getString("username");
        }
        
        dbHelper = new DatabaseHelper(requireContext());
        
        EditText inputDate = view.findViewById(R.id.inputDate);
        EditText inputWeight = view.findViewById(R.id.inputWeight);
        Button btnAction = view.findViewById(R.id.btnAdd);

        // We added a big button to the layout so the goal feature is unmissable.
        view.findViewById(R.id.btnSetGoal).setOnClickListener(v -> showSetGoalDialog());

        loadDataFromDb();

        RecyclerView recycler = view.findViewById(R.id.recycler);
        
        adapter = new WeightAdapter(weightList, new WeightAdapter.OnItemClickListener() {
            @Override
            public void onDelete(long id, int position) {
                dbHelper.deleteWeight(id);
                weightList.remove(position);
                adapter.notifyItemRemoved(position);
                resetForm(inputDate, inputWeight, btnAction);
            }

            @Override
            public void onEdit(WeightRow row, int position) {
                inputDate.setText(row.getDate());
                inputWeight.setText(row.getWeight().replace(" lb", ""));
                selectedId = row.getId();
                selectedPosition = position;
                btnAction.setText("Update");
            }
        });
        
        recycler.setLayoutManager(new LinearLayoutManager(getContext()));
        recycler.setAdapter(adapter);

        // One button handles both Add and Update based on state.
        btnAction.setOnClickListener(v -> {
            String dateStr = inputDate.getText().toString();
            String weightStr = inputWeight.getText().toString();

            if (!dateStr.isEmpty() && !weightStr.isEmpty()) {
                // Formatting consistency.
                String formattedWeight = weightStr.contains("lb") ? weightStr : weightStr + " lb";
                
                if (selectedId == -1) {
                    // New Entry
                    long id = dbHelper.addWeight(currentUsername, dateStr, formattedWeight);
                    if (id != -1) {
                        weightList.add(new WeightRow(id, dateStr, formattedWeight));
                        adapter.notifyItemInserted(weightList.size() - 1);
                        checkGoalAndNotify(weightStr);
                    }
                } else {
                    // Update Entry
                    if (dbHelper.updateWeight(selectedId, dateStr, formattedWeight)) {
                        WeightRow row = weightList.get(selectedPosition);
                        row.setDate(dateStr);
                        row.setWeight(formattedWeight);
                        adapter.notifyItemChanged(selectedPosition);
                        checkGoalAndNotify(weightStr);
                    }
                }
                resetForm(inputDate, inputWeight, btnAction);
            }
        });

        // Simple logout navigation.
        view.findViewById(R.id.btnLogout).setOnClickListener(v -> {
            Navigation.findNavController(v).navigate(R.id.action_grid_to_login);
        });
    }

    // Modal dialog for setting the goal weight.
    // Saves to SharedPreferences keyed by username to keep users distinct.
    private void showSetGoalDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
        builder.setTitle("Set Goal Weight");

        final EditText input = new EditText(requireContext());
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        
        SharedPreferences prefs = requireContext().getSharedPreferences(PREFS_GOAL, Context.MODE_PRIVATE);
        String current = prefs.getString(currentUsername, "");
        
        if (!current.isEmpty()) {
            input.setText(current);
        } else {
            input.setHint("e.g. 150");
        }
        
        builder.setView(input);

        builder.setPositiveButton("Save", (dialog, which) -> {
            String val = input.getText().toString();
            if (!val.isEmpty()) {
                prefs.edit().putString(currentUsername, val).apply();
                Toast.makeText(getContext(), "Goal set to " + val + " lbs", Toast.LENGTH_SHORT).show();
            }
        });
        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());
        builder.show();
    }

    // Checks if the new weight hits the target and sends SMS if permitted.
    private void checkGoalAndNotify(String weightStr) {
        SharedPreferences prefs = requireContext().getSharedPreferences(PREFS_GOAL, Context.MODE_PRIVATE);
        String goalStr = prefs.getString(currentUsername, null);
        
        if (goalStr == null) return; 

        try {
            double current = Double.parseDouble(weightStr.replace(" lb", "").trim());
            double goal = Double.parseDouble(goalStr);

            // Trigger if current weight is at or below goal (weight loss context).
            if (current <= goal) {
                if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.SEND_SMS) 
                        == PackageManager.PERMISSION_GRANTED) {
                    
                    // Port 5556 is the loopback for the Android Emulator.
                    SmsManager smsManager = SmsManager.getDefault();
                    smsManager.sendTextMessage("5556", null, 
                            "Congrats! You hit your goal of " + goal + " lbs!", null, null);
                    
                    Toast.makeText(getContext(), "Goal reached! SMS sent.", Toast.LENGTH_SHORT).show();
                } else {
                    // Graceful fallback if they haven't granted permissions yet.
                    Toast.makeText(getContext(), "Goal reached! (Enable SMS for alerts)", Toast.LENGTH_SHORT).show();
                }
            }
        } catch (NumberFormatException e) {
            // Ignore malformed input.
        }
    }

    private void resetForm(EditText date, EditText weight, Button btn) {
        date.getText().clear();
        weight.getText().clear();
        btn.setText("Add");
        selectedId = -1;
        selectedPosition = -1;
    }
    
    private void loadDataFromDb() {
        weightList.clear();
        Cursor cursor = dbHelper.getUserWeights(currentUsername);
        if (cursor != null && cursor.moveToFirst()) {
            do {
                // ID=0, DATE=2, WEIGHT=3 (skipping username_ref at 1)
                long id = cursor.getLong(0); 
                String date = cursor.getString(2);
                String weight = cursor.getString(3);
                weightList.add(new WeightRow(id, date, weight));
            } while (cursor.moveToNext());
            cursor.close();
        }
    }
}
