﻿import { Injectable, inject } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { tap } from "rxjs/operators";

@Injectable({
  providedIn: "root"
})
export class AuthService {
  private http = inject(HttpClient);
  private baseUrl = "/api";

  // Helper so we do not touch localStorage when Angular is running on the server
  private isBrowser(): boolean {
    return typeof window !== "undefined" && typeof localStorage !== "undefined";
  }

  login(username: string, password: string) {
    return this.http
      .post<{ token: string }>(this.baseUrl + "/login", { username, password })
      .pipe(
        tap(res => {
          if (this.isBrowser() && res.token) {
            localStorage.setItem("travlr-token", res.token);
          }
        })
      );
  }

  logout(): void {
    if (this.isBrowser()) {
      localStorage.removeItem("travlr-token");
    }
  }

  getToken(): string | null {
    if (!this.isBrowser()) {
      return null;
    }
    return localStorage.getItem("travlr-token");
  }

  isLoggedIn(): boolean {
    return !!this.getToken();
  }
}
