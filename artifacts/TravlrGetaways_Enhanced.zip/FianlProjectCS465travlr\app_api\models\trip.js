/**
 * Trip Model with Database Indexing Enhancement
 *
 * CS 499 Milestone Four: Databases Enhancement
 * Artifact: Travlr Getaways (CS 465 Full Stack Development)
 *
 * COURSE OUTCOME 4: Demonstrates ability to use well-founded techniques, skills,
 * and tools for implementing database solutions through strategic index creation.
 *
 * COURSE OUTCOME 3: Design and evaluate computing solutions using algorithmic
 * principles and manage trade-offs in design choices. Indexes represent a classic
 * space-time trade-off: we use additional storage to achieve faster query times.
 *
 * PERFORMANCE ANALYSIS:
 * Without indexes, MongoDB performs a collection scan (O(n)) for each query.
 * With B-tree indexes, lookups become O(log n), providing significant performance
 * gains as the dataset grows. For a collection with 1 million documents:
 *   - Collection scan: ~1,000,000 comparisons worst case
 *   - B-tree index lookup: ~20 comparisons (log2 of 1M)
 *
 * TRADE-OFFS:
 * - Storage: Each index requires additional disk space (typically 10-20% of data size)
 * - Write Performance: Inserts/updates must maintain index structures, adding O(log n) overhead
 * - Memory: Indexes should fit in RAM for optimal performance
 *
 * @module models/trip
 */
const mongoose = require("mongoose");

const tripSchema = new mongoose.Schema({
  code:   { type: String, required: [true, "Trip code required"], unique: true, trim: true },
  name:   { type: String, required: [true, "Trip name required"], trim: true, maxlength: 120 },
  price:  { type: Number, required: true, min: [0, "Price must be positive"] },
  nights: { type: Number, required: true, min: [1, "At least 1 night"] },
  img:    { type: String, trim: true },
  summary:{ type: String, trim: true, maxlength: 500 },
  createdOn: { type: Date, default: Date.now }
}, { collection: "trips" });

/**
 * DATABASE INDEXING STRATEGY
 *
 * COURSE OUTCOME 4: Implementing well-founded database optimization techniques.
 *
 * Index 1: Single-field index on 'name'
 * Purpose: Enables efficient text-based trip searches
 * Complexity: O(log n) lookup vs O(n) collection scan
 * Use case: Users frequently search trips by destination name
 */
tripSchema.index({ name: 1 });

/**
 * Index 2: Single-field index on 'price'
 * Purpose: Supports price-based sorting and range queries
 * Complexity: O(log n) for range queries like { price: { $gte: 500, $lte: 1500 } }
 * Use case: Users filter trips by budget, sort by price low-to-high
 */
tripSchema.index({ price: 1 });

/**
 * Index 3: Compound index on 'price' and 'nights'
 * Purpose: Optimizes queries that filter or sort by both price and duration
 *
 * COURSE OUTCOME 3: This compound index demonstrates algorithmic design trade-offs.
 * The index order matters: { price: 1, nights: 1 } efficiently supports:
 *   - Queries on price alone
 *   - Queries on price AND nights
 *   - Sorts by price, then nights
 * But NOT queries on nights alone (would require a separate index)
 *
 * Use case: "Show me trips under $2000 that are 5-7 nights, sorted by price"
 */
tripSchema.index({ price: 1, nights: 1 });

/**
 * Index 4: Single-field index on 'createdOn' (descending)
 * Purpose: Supports efficient sorting by date for "newest trips" queries
 * Complexity: O(log n) to find insertion point for pagination
 * Use case: Display newest trips first on homepage, paginated results
 */
tripSchema.index({ createdOn: -1 });

/**
 * Index 5: Text index for full-text search on name and summary
 * Purpose: Enables MongoDB text search capabilities for search functionality
 *
 * COURSE OUTCOME 5: Security consideration - text indexes can expose data patterns.
 * We limit the index to non-sensitive fields only (name, summary).
 * Sensitive data like internal codes are excluded from text search.
 *
 * Use case: Search bar functionality - "Find trips mentioning 'beach' or 'mountain'"
 */
tripSchema.index({ name: "text", summary: "text" });

module.exports = mongoose.model("Trip", tripSchema);
