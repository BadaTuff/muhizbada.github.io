﻿require('dotenv').config();
const express = require("express");
const path = require("path");
const { engine } = require("express-handlebars");

require("./app_api/db"); const apiRouter = require("./app_api/routes"); const indexRouter = require("./app_server/routes/index");
const travelRouter = require("./app_server/routes/travel");

const app = express();

// expose a year var to all templates
app.use((req, res, next) => { res.locals.year = new Date().getFullYear(); next(); });

// Handlebars view engine
app.set("views", path.join(__dirname, "app_server", "views"));
app.engine("hbs", engine({
  extname: "hbs",
  defaultLayout: "layout",
  layoutsDir: path.join(__dirname, "app_server", "views", "layouts"),
  partialsDir: path.join(__dirname, "app_server", "views", "partials")
}));
app.set("view engine", "hbs");


app.use(express.json());
// Routes FIRST so "/" hits HBS
app.use("/", indexRouter);
app.use("/travel", travelRouter);

// Static assets after routes
app.use(express.static(path.join(__dirname, "public")));


app.use("/api", apiRouter);
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Travlr MVC app listening on http://localhost:${PORT}`);
});
module.exports = app;





