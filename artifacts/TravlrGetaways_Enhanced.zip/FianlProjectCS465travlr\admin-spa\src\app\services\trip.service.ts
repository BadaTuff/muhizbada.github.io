﻿import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";
import { Trip } from "../models/trip.model";

@Injectable({
  providedIn: "root"
})
export class TripService {
  private baseUrl = "/api/trips";

  constructor(private http: HttpClient) {}

  list(): Observable<Trip[]> {
    return this.http.get<Trip[]>(this.baseUrl);
  }

  get(code: string): Observable<Trip> {
    return this.http.get<Trip>(`${this.baseUrl}/${code}`);
  }

  create(trip: Trip): Observable<Trip> {
    return this.http.post<Trip>(this.baseUrl, trip);
  }

  update(code: string, patch: Partial<Trip>): Observable<Trip> {
    return this.http.put<Trip>(`${this.baseUrl}/${code}`, patch);
  }

  remove(code: string): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/${code}`);
  }
}
