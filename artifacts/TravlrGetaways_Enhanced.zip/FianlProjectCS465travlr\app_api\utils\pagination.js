/**
 * Pagination Utility Module
 *
 * CS 499 Milestone Four: Databases Enhancement
 * Artifact: Travlr Getaways (CS 465 Full Stack Development)
 *
 * COURSE OUTCOME 3: Design and evaluate computing solutions using algorithmic
 * principles and manage trade-offs in design choices.
 *
 * PAGINATION ALGORITHMS AND COMPLEXITY ANALYSIS:
 *
 * Skip/Limit Pagination (implemented here):
 * - Time Complexity: O(skip + limit) because MongoDB must traverse skipped documents
 * - Space Complexity: O(limit) for the returned documents
 * - Trade-off: Simple to implement but degrades for deep pages (e.g., page 10000)
 *
 * Alternative: Cursor-based Pagination (keyset pagination):
 * - Time Complexity: O(log n + limit) with proper indexing
 * - Space Complexity: O(limit)
 * - Trade-off: More complex API but consistent performance regardless of page depth
 *
 * For Travlr Getaways with expected dataset size of < 10,000 trips,
 * skip/limit pagination provides acceptable performance while maintaining
 * API simplicity. For larger datasets, cursor-based pagination would be preferred.
 *
 * COURSE OUTCOME 5: Security considerations for pagination:
 * - Maximum limit enforced to prevent denial-of-service via large page sizes
 * - Input validation prevents negative values and non-numeric inputs
 * - Default values ensure predictable behavior with missing parameters
 *
 * @module utils/pagination
 */

/**
 * Default pagination configuration
 * These values balance user experience with server resource protection
 */
const PAGINATION_DEFAULTS = {
  page: 1,           // First page (1-indexed for user-friendliness)
  limit: 10,         // Reasonable default matching common UI patterns
  maxLimit: 100      // Hard cap to prevent resource exhaustion attacks
};

/**
 * Parses and validates pagination parameters from request query string
 *
 * COURSE OUTCOME 5: Input validation is critical for security.
 * This function sanitizes user input to prevent:
 * - Integer overflow attacks (using parseInt with fallbacks)
 * - Denial of service via excessive limit values (maxLimit cap)
 * - Negative pagination values (Math.max with 1)
 *
 * @param {Object} query - Express request query object (req.query)
 * @param {string|number} [query.page] - Requested page number (1-indexed)
 * @param {string|number} [query.limit] - Requested items per page
 * @returns {Object} Validated pagination parameters
 * @returns {number} returns.page - Validated page number (minimum 1)
 * @returns {number} returns.limit - Validated limit (between 1 and maxLimit)
 * @returns {number} returns.skip - Calculated skip value for MongoDB query
 *
 * @example
 * // Request: GET /api/trips?page=2&limit=20
 * const params = parsePaginationParams({ page: '2', limit: '20' });
 * // Returns: { page: 2, limit: 20, skip: 20 }
 */
const parsePaginationParams = (query) => {
  // Parse page with validation: ensure integer, minimum of 1
  // parseInt handles string conversion; NaN check provides fallback
  let page = parseInt(query.page, 10);
  if (isNaN(page) || page < 1) {
    page = PAGINATION_DEFAULTS.page;
  }

  // Parse limit with validation: ensure integer, within allowed range
  // COURSE OUTCOME 5: maxLimit cap prevents resource exhaustion
  let limit = parseInt(query.limit, 10);
  if (isNaN(limit) || limit < 1) {
    limit = PAGINATION_DEFAULTS.limit;
  } else if (limit > PAGINATION_DEFAULTS.maxLimit) {
    limit = PAGINATION_DEFAULTS.maxLimit;
  }

  // Calculate skip value for MongoDB query
  // COURSE OUTCOME 3: skip = (page - 1) * limit
  // This formula converts 1-indexed pages to 0-indexed skip offsets
  // Example: page 3 with limit 10 -> skip 20 (skip first 20 documents)
  const skip = (page - 1) * limit;

  return { page, limit, skip };
};

/**
 * Builds a pagination metadata object for API responses
 *
 * COURSE OUTCOME 3: This function demonstrates algorithmic thinking by
 * calculating derived values that enhance API usability:
 * - Total pages: Math.ceil(totalDocs / limit) ensures partial pages are counted
 * - hasNextPage/hasPrevPage: Boolean flags for UI navigation controls
 *
 * @param {number} page - Current page number (1-indexed)
 * @param {number} limit - Items per page
 * @param {number} totalDocs - Total documents matching the query
 * @returns {Object} Pagination metadata for API response
 * @returns {number} returns.currentPage - Current page number
 * @returns {number} returns.itemsPerPage - Items per page
 * @returns {number} returns.totalItems - Total matching documents
 * @returns {number} returns.totalPages - Total number of pages
 * @returns {boolean} returns.hasNextPage - True if more pages exist
 * @returns {boolean} returns.hasPrevPage - True if previous pages exist
 *
 * @example
 * const meta = buildPaginationMeta(2, 10, 45);
 * // Returns: {
 * //   currentPage: 2,
 * //   itemsPerPage: 10,
 * //   totalItems: 45,
 * //   totalPages: 5,
 * //   hasNextPage: true,
 * //   hasPrevPage: true
 * // }
 */
const buildPaginationMeta = (page, limit, totalDocs) => {
  // Calculate total pages using ceiling division
  // This ensures partial pages are counted (e.g., 45 items / 10 per page = 5 pages)
  const totalPages = Math.ceil(totalDocs / limit);

  return {
    currentPage: page,
    itemsPerPage: limit,
    totalItems: totalDocs,
    totalPages: totalPages,
    hasNextPage: page < totalPages,
    hasPrevPage: page > 1
  };
};

/**
 * Express middleware for parsing pagination parameters
 *
 * Attaches validated pagination parameters to req.pagination for use
 * in route handlers. This middleware pattern promotes code reuse
 * and consistent pagination handling across all paginated endpoints.
 *
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 *
 * @example
 * // In routes/index.js:
 * router.get('/trips', paginationMiddleware, ctrlTrips.tripsList);
 *
 * // In controller:
 * const { page, limit, skip } = req.pagination;
 */
const paginationMiddleware = (req, res, next) => {
  req.pagination = parsePaginationParams(req.query);
  next();
};

module.exports = {
  PAGINATION_DEFAULTS,
  parsePaginationParams,
  buildPaginationMeta,
  paginationMiddleware
};
