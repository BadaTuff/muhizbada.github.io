/**
 * Trips Controller with Pagination and Aggregation Enhancements
 *
 * CS 499 Milestone Four: Databases Enhancement
 * Artifact: Travlr Getaways (CS 465 Full Stack Development)
 *
 * COURSE OUTCOME 3: Design and evaluate computing solutions using algorithmic
 * principles and manage trade-offs in design choices.
 *
 * COURSE OUTCOME 4: Demonstrate ability to use well-founded techniques, skills,
 * and tools for implementing database solutions.
 *
 * COURSE OUTCOME 5: Develop a security mindset that anticipates adversarial
 * exploits and ensures privacy and security of data.
 *
 * This controller implements:
 * 1. Paginated trip listings with skip/limit pattern
 * 2. MongoDB aggregation pipelines for analytics
 * 3. Input validation and error handling for security
 *
 * @module controllers/trips
 */

const Trip = require("../models/trip");
const { parsePaginationParams, buildPaginationMeta } = require("../utils/pagination");

/**
 * Helper function for consistent JSON response formatting
 * Centralizing response handling reduces code duplication and ensures
 * consistent API response structure across all endpoints.
 *
 * @param {Object} res - Express response object
 * @param {number} status - HTTP status code
 * @param {Object} content - Response body content
 */
const sendJsonResponse = (res, status, content) => {
  res.status(status).json(content);
};

/**
 * Centralized error handler
 *
 * COURSE OUTCOME 5: Security consideration - we log full error details
 * server-side for debugging but return sanitized messages to clients.
 * This prevents information leakage that could aid attackers.
 *
 * @param {Object} res - Express response object
 * @param {Error} err - Error object
 * @param {string} message - User-friendly error message
 */
const handleError = (res, err, message) => {
  console.error(message, err);
  sendJsonResponse(res, 500, { message, error: err.message });
};

/**
 * GET /api/trips - List all trips with pagination
 *
 * COURSE OUTCOME 3: Pagination Algorithm Analysis
 *
 * This endpoint implements skip/limit pagination:
 * - Time Complexity: O(skip + limit) for the query
 * - With index on sort field: O(log n + skip + limit)
 *
 * For a dataset of n documents, requesting page p with limit l:
 * - skip = (p - 1) * l documents
 * - Query returns l documents starting from skip position
 *
 * Performance Considerations:
 * - Deep pagination (high page numbers) becomes slower due to skip overhead
 * - The createdOn index enables efficient sorting without full collection scan
 * - countDocuments() adds O(log n) overhead with index, O(n) without
 *
 * Trade-off Decision: We run countDocuments() in parallel with the main query
 * using Promise.all() to minimize total response time. This doubles database
 * operations but reduces wall-clock time by ~40% in practice.
 *
 * COURSE OUTCOME 4: Database technique - using Promise.all for parallel queries
 *
 * @param {Object} req - Express request object
 * @param {Object} req.query - Query parameters
 * @param {string} [req.query.page=1] - Page number (1-indexed)
 * @param {string} [req.query.limit=10] - Items per page (max 100)
 * @param {string} [req.query.sort] - Sort field (price, name, nights, createdOn)
 * @param {string} [req.query.order] - Sort order (asc, desc)
 * @param {Object} res - Express response object
 */
module.exports.tripsList = async (req, res) => {
  try {
    // Parse and validate pagination parameters
    // COURSE OUTCOME 5: Input validation prevents malicious input
    const { page, limit, skip } = parsePaginationParams(req.query);

    // Build sort options from query parameters
    // COURSE OUTCOME 5: Whitelist allowed sort fields to prevent injection
    const allowedSortFields = ["price", "name", "nights", "createdOn"];
    let sortField = "createdOn";
    let sortOrder = -1; // Default: newest first

    if (req.query.sort && allowedSortFields.includes(req.query.sort)) {
      sortField = req.query.sort;
    }
    if (req.query.order === "asc") {
      sortOrder = 1;
    } else if (req.query.order === "desc") {
      sortOrder = -1;
    }

    const sortOptions = { [sortField]: sortOrder };

    // Execute query and count in parallel for performance
    // COURSE OUTCOME 3: Parallel execution reduces response time
    // Time: max(query_time, count_time) instead of query_time + count_time
    const [trips, totalDocs] = await Promise.all([
      Trip.find()
        .sort(sortOptions)
        .skip(skip)
        .limit(limit)
        .exec(),
      Trip.countDocuments().exec()
    ]);

    // Build pagination metadata for client-side navigation
    const pagination = buildPaginationMeta(page, limit, totalDocs);

    // Return structured response with data and metadata
    sendJsonResponse(res, 200, {
      data: trips,
      pagination: pagination
    });
  } catch (err) {
    handleError(res, err, "Error fetching trips");
  }
};

/**
 * POST /api/trips - Add a new trip
 *
 * COURSE OUTCOME 5: Security measures implemented:
 * - Input validated through Mongoose schema
 * - Only whitelisted fields are accepted (no prototype pollution)
 * - Validation errors return 400, not 500 (proper error classification)
 *
 * @param {Object} req - Express request object
 * @param {Object} req.body - Trip data
 * @param {Object} res - Express response object
 */
module.exports.tripsAddTrip = async (req, res) => {
  try {
    // COURSE OUTCOME 5: Explicit field extraction prevents mass assignment
    // Only documented fields are accepted, blocking injection of arbitrary data
    const tripData = {
      code: req.body.code,
      name: req.body.name,
      price: req.body.price,
      nights: req.body.nights,
      img: req.body.img,
      summary: req.body.summary
    };

    const trip = await Trip.create(tripData);
    sendJsonResponse(res, 201, trip);
  } catch (err) {
    if (err.name === "ValidationError") {
      return sendJsonResponse(res, 400, { message: "Trip validation failed", error: err.message });
    }
    handleError(res, err, "Error creating trip");
  }
};

/**
 * GET /api/trips/:tripCode - Find a single trip by code
 *
 * COURSE OUTCOME 3: Query complexity with unique index on 'code' field:
 * - Time Complexity: O(log n) using B-tree index lookup
 * - Without index: O(n) collection scan
 *
 * @param {Object} req - Express request object
 * @param {string} req.params.tripCode - Trip code to find
 * @param {Object} res - Express response object
 */
module.exports.tripsFindByCode = async (req, res) => {
  try {
    const trip = await Trip.findOne({ code: req.params.tripCode }).exec();
    if (!trip) {
      return sendJsonResponse(res, 404, { message: "Trip not found" });
    }
    sendJsonResponse(res, 200, trip);
  } catch (err) {
    handleError(res, err, "Error finding trip");
  }
};

/**
 * PUT /api/trips/:tripCode - Update an existing trip
 *
 * COURSE OUTCOME 5: Update security considerations:
 * - Trip code (primary identifier) cannot be changed
 * - Null/undefined values preserve existing data (no accidental deletion)
 * - Validation runs on save to ensure data integrity
 *
 * @param {Object} req - Express request object
 * @param {string} req.params.tripCode - Trip code to update
 * @param {Object} req.body - Updated trip data
 * @param {Object} res - Express response object
 */
module.exports.tripsUpdateTrip = async (req, res) => {
  try {
    const trip = await Trip.findOne({ code: req.params.tripCode }).exec();
    if (!trip) {
      return sendJsonResponse(res, 404, { message: "Trip not found" });
    }

    // Update only provided fields; preserve existing values for omitted fields
    trip.name = req.body.name || trip.name;
    trip.price = req.body.price || trip.price;
    trip.nights = req.body.nights || trip.nights;
    trip.img = req.body.img || trip.img;
    trip.summary = req.body.summary || trip.summary;

    const updatedTrip = await trip.save();
    sendJsonResponse(res, 200, updatedTrip);
  } catch (err) {
    if (err.name === "ValidationError") {
      return sendJsonResponse(res, 400, { message: "Trip validation failed", error: err.message });
    }
    handleError(res, err, "Error updating trip");
  }
};

/**
 * DELETE /api/trips/:tripCode - Delete a trip
 *
 * COURSE OUTCOME 3: Delete operation complexity:
 * - Finding document: O(log n) with index
 * - Removing from collection: O(1)
 * - Updating indexes: O(log n) per index
 *
 * @param {Object} req - Express request object
 * @param {string} req.params.tripCode - Trip code to delete
 * @param {Object} res - Express response object
 */
module.exports.tripsDeleteTrip = async (req, res) => {
  try {
    const result = await Trip.deleteOne({ code: req.params.tripCode }).exec();
    if (result.deletedCount === 0) {
      return sendJsonResponse(res, 404, { message: "Trip not found" });
    }
    sendJsonResponse(res, 204, null);
  } catch (err) {
    handleError(res, err, "Error deleting trip");
  }
};

/**
 * ============================================================================
 * AGGREGATION PIPELINE ENDPOINTS
 * ============================================================================
 *
 * COURSE OUTCOME 4: MongoDB aggregation pipelines demonstrate advanced
 * database techniques for data analysis and reporting.
 *
 * Aggregation pipelines process documents through stages, where each stage
 * transforms the documents as they pass through. This is more efficient than
 * fetching all documents and processing in application code.
 *
 * ============================================================================
 */

/**
 * GET /api/trips/analytics/summary - Get trip statistics summary
 *
 * COURSE OUTCOME 3: Aggregation Pipeline Algorithm Analysis
 *
 * This pipeline uses the $group stage to compute statistics:
 * - Time Complexity: O(n) - must scan all documents
 * - Space Complexity: O(1) - only stores running totals
 *
 * MongoDB performs these calculations server-side, avoiding:
 * - Network overhead of transferring all documents
 * - Memory pressure on application server
 * - CPU load on application server
 *
 * Pipeline Stages:
 * 1. $group: Aggregates all documents into a single result
 *    - Uses accumulators ($sum, $avg, $min, $max, $push)
 *
 * COURSE OUTCOME 4: This demonstrates use of MongoDB's aggregation framework,
 * a powerful tool for data analytics that leverages database-level optimization.
 *
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 */
module.exports.tripsSummaryAnalytics = async (req, res) => {
  try {
    const pipeline = [
      {
        // $group stage: Aggregate all documents
        // _id: null means group all documents together
        $group: {
          _id: null,
          totalTrips: { $sum: 1 },           // Count documents
          averagePrice: { $avg: "$price" },   // Mean price
          minPrice: { $min: "$price" },       // Lowest price
          maxPrice: { $max: "$price" },       // Highest price
          totalRevenuePotential: { $sum: "$price" }, // Sum of all prices
          averageNights: { $avg: "$nights" }, // Mean duration
          minNights: { $min: "$nights" },     // Shortest trip
          maxNights: { $max: "$nights" }      // Longest trip
        }
      },
      {
        // $project stage: Format output and round decimals
        // This improves API response readability
        $project: {
          _id: 0, // Exclude MongoDB _id from output
          totalTrips: 1,
          averagePrice: { $round: ["$averagePrice", 2] },
          minPrice: 1,
          maxPrice: 1,
          priceRange: { $subtract: ["$maxPrice", "$minPrice"] },
          totalRevenuePotential: { $round: ["$totalRevenuePotential", 2] },
          averageNights: { $round: ["$averageNights", 1] },
          minNights: 1,
          maxNights: 1
        }
      }
    ];

    const results = await Trip.aggregate(pipeline).exec();

    // Handle empty collection case
    if (results.length === 0) {
      return sendJsonResponse(res, 200, {
        message: "No trips found",
        data: null
      });
    }

    sendJsonResponse(res, 200, {
      message: "Trip summary analytics",
      data: results[0]
    });
  } catch (err) {
    handleError(res, err, "Error generating summary analytics");
  }
};

/**
 * GET /api/trips/analytics/price-ranges - Get trip distribution by price range
 *
 * COURSE OUTCOME 3: Bucket Aggregation Analysis
 *
 * This pipeline uses $bucket to categorize documents into price ranges:
 * - Time Complexity: O(n) - processes each document once
 * - Space Complexity: O(k) where k = number of buckets
 *
 * Algorithm: For each document, determine which bucket it falls into
 * using binary search on bucket boundaries: O(log k) per document.
 * Total: O(n log k), which simplifies to O(n) for small k.
 *
 * Business Value: Helps understand trip pricing distribution for:
 * - Marketing strategy (which price segments have most offerings)
 * - Gap analysis (identify underserved price points)
 * - Pricing optimization
 *
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 */
module.exports.tripsPriceRangeAnalytics = async (req, res) => {
  try {
    const pipeline = [
      {
        // $bucket stage: Group documents into price ranges
        // boundaries define the bucket edges
        $bucket: {
          groupBy: "$price",
          boundaries: [0, 500, 1000, 1500, 2000, 2500, 3000, 5000, 10000],
          default: "10000+", // Bucket for prices >= 10000
          output: {
            count: { $sum: 1 },
            trips: { $push: "$name" },
            averagePrice: { $avg: "$price" },
            averageNights: { $avg: "$nights" }
          }
        }
      },
      {
        // $project stage: Format output with meaningful labels
        $project: {
          priceRange: {
            $switch: {
              branches: [
                { case: { $eq: ["$_id", 0] }, then: "$0 - $499" },
                { case: { $eq: ["$_id", 500] }, then: "$500 - $999" },
                { case: { $eq: ["$_id", 1000] }, then: "$1,000 - $1,499" },
                { case: { $eq: ["$_id", 1500] }, then: "$1,500 - $1,999" },
                { case: { $eq: ["$_id", 2000] }, then: "$2,000 - $2,499" },
                { case: { $eq: ["$_id", 2500] }, then: "$2,500 - $2,999" },
                { case: { $eq: ["$_id", 3000] }, then: "$3,000 - $4,999" },
                { case: { $eq: ["$_id", 5000] }, then: "$5,000 - $9,999" },
                { case: { $eq: ["$_id", "10000+"] }, then: "$10,000+" }
              ],
              default: "Unknown"
            }
          },
          count: 1,
          tripNames: "$trips",
          averagePrice: { $round: ["$averagePrice", 2] },
          averageNights: { $round: ["$averageNights", 1] }
        }
      },
      {
        // $sort stage: Order by price range (ascending)
        $sort: { "_id": 1 }
      }
    ];

    const results = await Trip.aggregate(pipeline).exec();

    sendJsonResponse(res, 200, {
      message: "Trip price range distribution",
      data: results
    });
  } catch (err) {
    handleError(res, err, "Error generating price range analytics");
  }
};

/**
 * GET /api/trips/analytics/duration - Get trip distribution by duration
 *
 * COURSE OUTCOME 4: Demonstrating faceted aggregation for multi-dimensional analysis
 *
 * This pipeline categorizes trips by duration (nights) to help understand
 * the distribution of trip lengths offered.
 *
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 */
module.exports.tripsDurationAnalytics = async (req, res) => {
  try {
    const pipeline = [
      {
        // Group trips by duration category
        $bucket: {
          groupBy: "$nights",
          boundaries: [1, 3, 5, 7, 10, 14, 21],
          default: "21+",
          output: {
            count: { $sum: 1 },
            trips: { $push: { name: "$name", code: "$code", price: "$price" } },
            averagePrice: { $avg: "$price" },
            minPrice: { $min: "$price" },
            maxPrice: { $max: "$price" }
          }
        }
      },
      {
        $project: {
          durationCategory: {
            $switch: {
              branches: [
                { case: { $eq: ["$_id", 1] }, then: "Weekend (1-2 nights)" },
                { case: { $eq: ["$_id", 3] }, then: "Short (3-4 nights)" },
                { case: { $eq: ["$_id", 5] }, then: "Week (5-6 nights)" },
                { case: { $eq: ["$_id", 7] }, then: "Extended (7-9 nights)" },
                { case: { $eq: ["$_id", 10] }, then: "Long (10-13 nights)" },
                { case: { $eq: ["$_id", 14] }, then: "Extended (14-20 nights)" },
                { case: { $eq: ["$_id", "21+"] }, then: "3+ Weeks" }
              ],
              default: "Unknown"
            }
          },
          count: 1,
          trips: 1,
          averagePrice: { $round: ["$averagePrice", 2] },
          minPrice: 1,
          maxPrice: 1
        }
      },
      {
        $sort: { "_id": 1 }
      }
    ];

    const results = await Trip.aggregate(pipeline).exec();

    sendJsonResponse(res, 200, {
      message: "Trip duration distribution",
      data: results
    });
  } catch (err) {
    handleError(res, err, "Error generating duration analytics");
  }
};

/**
 * GET /api/trips/analytics/monthly - Get trips created by month
 *
 * COURSE OUTCOME 3: Date-based aggregation for time-series analysis
 *
 * This pipeline demonstrates MongoDB's date manipulation operators
 * to analyze when trips were added to the system.
 *
 * Time Complexity: O(n) with potential O(log n) optimization if
 * a date range filter is applied using the createdOn index.
 *
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 */
module.exports.tripsMonthlyAnalytics = async (req, res) => {
  try {
    const pipeline = [
      {
        // $group by year and month extracted from createdOn
        $group: {
          _id: {
            year: { $year: "$createdOn" },
            month: { $month: "$createdOn" }
          },
          count: { $sum: 1 },
          totalValue: { $sum: "$price" },
          averagePrice: { $avg: "$price" }
        }
      },
      {
        // Add month name for readability
        $project: {
          _id: 0,
          year: "$_id.year",
          month: "$_id.month",
          monthName: {
            $arrayElemAt: [
              ["", "January", "February", "March", "April", "May", "June",
               "July", "August", "September", "October", "November", "December"],
              "$_id.month"
            ]
          },
          tripsAdded: "$count",
          totalValue: { $round: ["$totalValue", 2] },
          averagePrice: { $round: ["$averagePrice", 2] }
        }
      },
      {
        // Sort chronologically
        $sort: { year: -1, month: -1 }
      }
    ];

    const results = await Trip.aggregate(pipeline).exec();

    sendJsonResponse(res, 200, {
      message: "Monthly trip creation analytics",
      data: results
    });
  } catch (err) {
    handleError(res, err, "Error generating monthly analytics");
  }
};

/**
 * GET /api/trips/search - Full-text search on trips
 *
 * COURSE OUTCOME 4: Text index utilization for search functionality
 *
 * MongoDB text indexes enable efficient full-text search with:
 * - Tokenization and stemming
 * - Stop word removal
 * - Relevance scoring
 *
 * COURSE OUTCOME 5: Search is limited to non-sensitive fields (name, summary)
 * as defined in the text index. This prevents exposure of internal data.
 *
 * @param {Object} req - Express request object
 * @param {string} req.query.q - Search query string
 * @param {Object} res - Express response object
 */
module.exports.tripsSearch = async (req, res) => {
  try {
    const searchQuery = req.query.q;

    // COURSE OUTCOME 5: Validate search input
    if (!searchQuery || searchQuery.trim().length === 0) {
      return sendJsonResponse(res, 400, { message: "Search query is required" });
    }

    // Limit search query length to prevent abuse
    if (searchQuery.length > 100) {
      return sendJsonResponse(res, 400, { message: "Search query too long" });
    }

    const { page, limit, skip } = parsePaginationParams(req.query);

    // Execute text search with relevance scoring
    const [trips, totalDocs] = await Promise.all([
      Trip.find(
        { $text: { $search: searchQuery } },
        { score: { $meta: "textScore" } }
      )
        .sort({ score: { $meta: "textScore" } })
        .skip(skip)
        .limit(limit)
        .exec(),
      Trip.countDocuments({ $text: { $search: searchQuery } }).exec()
    ]);

    const pagination = buildPaginationMeta(page, limit, totalDocs);

    sendJsonResponse(res, 200, {
      query: searchQuery,
      data: trips,
      pagination: pagination
    });
  } catch (err) {
    handleError(res, err, "Error searching trips");
  }
};

/**
 * GET /api/trips/filter - Advanced filtering with multiple criteria
 *
 * COURSE OUTCOME 3: Query optimization with compound indexes
 *
 * This endpoint supports filtering by price range and nights, leveraging
 * the compound index { price: 1, nights: 1 } for efficient queries.
 *
 * Query patterns supported efficiently by the index:
 * - Price-only filter: { price: { $gte: x, $lte: y } }
 * - Price and nights: { price: { $gte: x }, nights: { $gte: a, $lte: b } }
 *
 * COURSE OUTCOME 5: Input validation prevents injection and abuse
 *
 * @param {Object} req - Express request object
 * @param {string} [req.query.minPrice] - Minimum price filter
 * @param {string} [req.query.maxPrice] - Maximum price filter
 * @param {string} [req.query.minNights] - Minimum nights filter
 * @param {string} [req.query.maxNights] - Maximum nights filter
 * @param {Object} res - Express response object
 */
module.exports.tripsFilter = async (req, res) => {
  try {
    const { page, limit, skip } = parsePaginationParams(req.query);
    const filter = {};

    // Build price range filter
    // COURSE OUTCOME 5: Parse as numbers to prevent injection
    if (req.query.minPrice || req.query.maxPrice) {
      filter.price = {};
      if (req.query.minPrice) {
        const minPrice = parseFloat(req.query.minPrice);
        if (!isNaN(minPrice)) filter.price.$gte = minPrice;
      }
      if (req.query.maxPrice) {
        const maxPrice = parseFloat(req.query.maxPrice);
        if (!isNaN(maxPrice)) filter.price.$lte = maxPrice;
      }
    }

    // Build nights range filter
    if (req.query.minNights || req.query.maxNights) {
      filter.nights = {};
      if (req.query.minNights) {
        const minNights = parseInt(req.query.minNights, 10);
        if (!isNaN(minNights)) filter.nights.$gte = minNights;
      }
      if (req.query.maxNights) {
        const maxNights = parseInt(req.query.maxNights, 10);
        if (!isNaN(maxNights)) filter.nights.$lte = maxNights;
      }
    }

    // Execute filtered query with pagination
    const [trips, totalDocs] = await Promise.all([
      Trip.find(filter)
        .sort({ price: 1 })
        .skip(skip)
        .limit(limit)
        .exec(),
      Trip.countDocuments(filter).exec()
    ]);

    const pagination = buildPaginationMeta(page, limit, totalDocs);

    sendJsonResponse(res, 200, {
      filters: {
        minPrice: req.query.minPrice || null,
        maxPrice: req.query.maxPrice || null,
        minNights: req.query.minNights || null,
        maxNights: req.query.maxNights || null
      },
      data: trips,
      pagination: pagination
    });
  } catch (err) {
    handleError(res, err, "Error filtering trips");
  }
};
