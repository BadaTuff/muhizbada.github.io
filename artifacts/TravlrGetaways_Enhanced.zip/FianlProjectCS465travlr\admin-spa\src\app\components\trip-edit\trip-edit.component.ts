﻿import { Component, OnInit } from "@angular/core";
import { CommonModule } from "@angular/common";
import { ReactiveFormsModule, FormBuilder, Validators } from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";
import { TripService } from "../../services/trip.service";

@Component({
  selector: "app-trip-edit",
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: "./trip-edit.component.html",
  styleUrls: ["./trip-edit.component.css"]
})
export class TripEditComponent implements OnInit {
  code = "";
  loading = false;
  saving = false;
  errorMsg = "";

  form = this.fb.group({
    name: ["", [Validators.required]],
    price: [0, [Validators.required, Validators.min(0)]],
    nights: [1, [Validators.required, Validators.min(1)]],
    img: [""],
    summary: [""]
  });

  constructor(
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private api: TripService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.code = this.route.snapshot.paramMap.get("code") ?? "";
    if (!this.code) {
      this.errorMsg = "Missing trip code in route";
      return;
    }
    this.loadTrip();
  }

  loadTrip(): void {
    this.loading = true;
    this.api.get(this.code).subscribe({
      next: t => {
        this.form.patchValue({
          name: t.name,
          price: t.price,
          nights: t.nights,
          img: t.img ?? "",
          summary: t.summary ?? ""
        });
        this.loading = false;
      },
      error: e => {
        this.errorMsg = `Load failed: ${e?.error?.message ?? e?.message ?? e}`;
        this.loading = false;
      }
    });
  }

  save(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    this.saving = true;
    this.errorMsg = "";
    this.api.update(this.code, this.form.value as any).subscribe({
      next: () => {
        this.saving = false;
        this.router.navigate(["/trips"]);
      },
      error: e => {
        this.saving = false;
        this.errorMsg = `Save failed: ${e?.error?.message ?? e?.message ?? e}`;
      }
    });
  }
}
