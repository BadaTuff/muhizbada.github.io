/**
 * API Routes Configuration with Enhanced Database Endpoints
 *
 * CS 499 Milestone Four: Databases Enhancement
 * Artifact: Travlr Getaways (CS 465 Full Stack Development)
 *
 * COURSE OUTCOME 4: Demonstrates ability to use well-founded techniques, skills,
 * and tools for implementing database solutions through RESTful API design.
 *
 * COURSE OUTCOME 5: Develop a security mindset that anticipates adversarial
 * exploits through JWT authentication middleware and route protection.
 *
 * API Endpoints Overview:
 * - GET  /api/trips                    - List trips with pagination
 * - POST /api/trips                    - Create trip (authenticated)
 * - GET  /api/trips/search             - Full-text search
 * - GET  /api/trips/filter             - Advanced filtering
 * - GET  /api/trips/analytics/summary  - Trip statistics
 * - GET  /api/trips/analytics/price-ranges - Price distribution
 * - GET  /api/trips/analytics/duration - Duration distribution
 * - GET  /api/trips/analytics/monthly  - Monthly creation stats
 * - GET  /api/trips/:tripCode          - Get single trip
 * - PUT  /api/trips/:tripCode          - Update trip (authenticated)
 * - DELETE /api/trips/:tripCode        - Delete trip (authenticated)
 * - POST /api/register                 - User registration
 * - POST /api/login                    - User authentication
 *
 * @module routes/index
 */

const express = require("express");
const router = express.Router();

const ctrlTrips = require("../controllers/trips");
const ctrlAuth = require("../controllers/auth");
const jwt = require("jsonwebtoken");

/**
 * JWT Secret Configuration
 *
 * COURSE OUTCOME 5: Security best practice - use environment variable for secrets.
 * The fallback value is for development only; production must set JWT_SECRET.
 *
 * In production, this should be:
 * - At least 256 bits of entropy
 * - Stored in environment variables or secrets manager
 * - Rotated periodically
 */
const jwtSecret = process.env.JWT_SECRET || "travlrJwtSecret";

/**
 * Authentication Middleware
 *
 * COURSE OUTCOME 5: Security implementation for protected routes.
 *
 * This middleware:
 * 1. Extracts JWT from Authorization header (Bearer token format)
 * 2. Verifies token signature and expiration
 * 3. Attaches decoded payload to request for downstream use
 *
 * Security considerations:
 * - Tokens are verified on every protected request (stateless auth)
 * - Invalid/expired tokens return 401 (not 403) to avoid leaking info
 * - Error messages are generic to prevent enumeration attacks
 *
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
const requireAuth = (req, res, next) => {
  const authHeader = req.headers.authorization || "";
  const token = authHeader.startsWith("Bearer ")
    ? authHeader.substring(7)
    : null;

  if (!token) {
    return res.status(401).json({ message: "No token provided" });
  }

  jwt.verify(token, jwtSecret, (err, payload) => {
    if (err) {
      return res.status(401).json({ message: "Token invalid" });
    }
    req.user = payload;
    next();
  });
};

/**
 * ============================================================================
 * TRIP ROUTES - Core CRUD Operations with Pagination
 * ============================================================================
 *
 * COURSE OUTCOME 3: Route ordering matters for Express pattern matching.
 * More specific routes (e.g., /trips/search) must be defined before
 * parameterized routes (e.g., /trips/:tripCode) to avoid misinterpretation.
 *
 * ============================================================================
 */

/**
 * Search and Filter Endpoints
 * These must come BEFORE the :tripCode route to avoid "search" being
 * interpreted as a trip code parameter.
 */
router.get("/trips/search", ctrlTrips.tripsSearch);
router.get("/trips/filter", ctrlTrips.tripsFilter);

/**
 * Analytics Endpoints
 *
 * COURSE OUTCOME 4: Aggregation pipeline routes for business intelligence.
 * These endpoints expose MongoDB aggregation results through RESTful API.
 */
router.get("/trips/analytics/summary", ctrlTrips.tripsSummaryAnalytics);
router.get("/trips/analytics/price-ranges", ctrlTrips.tripsPriceRangeAnalytics);
router.get("/trips/analytics/duration", ctrlTrips.tripsDurationAnalytics);
router.get("/trips/analytics/monthly", ctrlTrips.tripsMonthlyAnalytics);

/**
 * Main Trip Collection Routes
 *
 * GET  /api/trips - Public endpoint, returns paginated trip list
 * POST /api/trips - Protected endpoint, requires authentication
 *
 * COURSE OUTCOME 5: Write operations (POST, PUT, DELETE) require authentication
 * to prevent unauthorized data modification.
 */
router
  .route("/trips")
  .get(ctrlTrips.tripsList)
  .post(requireAuth, ctrlTrips.tripsAddTrip);

/**
 * Single Trip Routes (by trip code)
 *
 * GET    /api/trips/:tripCode - Public, retrieve trip details
 * PUT    /api/trips/:tripCode - Protected, update trip
 * DELETE /api/trips/:tripCode - Protected, remove trip
 *
 * COURSE OUTCOME 3: Using tripCode (business identifier) instead of MongoDB _id
 * provides cleaner URLs and decouples API from database implementation.
 */
router
  .route("/trips/:tripCode")
  .get(ctrlTrips.tripsFindByCode)
  .put(requireAuth, ctrlTrips.tripsUpdateTrip)
  .delete(requireAuth, ctrlTrips.tripsDeleteTrip);

/**
 * ============================================================================
 * AUTHENTICATION ROUTES
 * ============================================================================
 *
 * COURSE OUTCOME 5: User authentication endpoints.
 *
 * POST /api/register - Create new user account
 * POST /api/login    - Authenticate and receive JWT
 *
 * Both endpoints are public (no requireAuth middleware) as users need
 * to access them before they have a token.
 *
 * ============================================================================
 */
router.post("/register", ctrlAuth.register);
router.post("/login", ctrlAuth.login);

module.exports = router;
