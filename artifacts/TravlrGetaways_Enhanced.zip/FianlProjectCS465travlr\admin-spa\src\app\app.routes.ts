﻿import { Routes } from "@angular/router";
import { TripListComponent } from "./components/trip-list/trip-list.component";
import { TripEditComponent } from "./components/trip-edit/trip-edit.component";
import { TripAddComponent } from "./components/trip-add/trip-add.component";
import { LoginComponent } from "./components/login/login.component";
import { authGuard } from "./services/auth.guard";

export const routes: Routes = [
  { path: "", redirectTo: "trips", pathMatch: "full" },
  { path: "login", component: LoginComponent },
  { path: "trips", component: TripListComponent, canActivate: [authGuard] },
  { path: "trips/add", component: TripAddComponent, canActivate: [authGuard] },
  { path: "trips/:code/edit", component: TripEditComponent, canActivate: [authGuard] },
  { path: "**", redirectTo: "trips" }
];
