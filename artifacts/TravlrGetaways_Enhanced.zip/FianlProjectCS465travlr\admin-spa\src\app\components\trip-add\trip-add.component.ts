﻿import { Component } from "@angular/core";
import { CommonModule } from "@angular/common";
import { ReactiveFormsModule, FormBuilder, Validators } from "@angular/forms";
import { Router } from "@angular/router";
import { TripService } from "../../services/trip.service";

@Component({
  selector: "app-trip-add",
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: "./trip-add.component.html",
  styleUrls: ["./trip-add.component.css"]
})
export class TripAddComponent {
  form = this.fb.group({
    code: ["", [Validators.required]],
    name: ["", [Validators.required]],
    price: [0, [Validators.required, Validators.min(0)]],
    nights: [1, [Validators.required, Validators.min(1)]],
    img: [""],
    summary: [""]
  });

  saving = false;
  errorMsg = "";

  constructor(
    private fb: FormBuilder,
    private api: TripService,
    private router: Router
  ) {}

  submit(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    this.saving = true;
    this.errorMsg = "";
    this.api.create(this.form.value as any).subscribe({
      next: () => {
        this.saving = false;
        this.router.navigate(["/trips"]);
      },
      error: e => {
        this.saving = false;
        this.errorMsg = `Save failed: ${e?.error?.message ?? e?.message ?? e}`;
      }
    });
  }
}
