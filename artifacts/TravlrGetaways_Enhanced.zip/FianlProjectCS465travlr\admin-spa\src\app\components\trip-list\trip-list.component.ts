﻿import { Component, OnInit } from "@angular/core";
import { CommonModule } from "@angular/common";
import { RouterModule } from "@angular/router";
import { Trip } from "../../models/trip.model";
import { TripService } from "../../services/trip.service";
import { TripCardComponent } from "../trip-card/trip-card.component";

@Component({
  selector: "app-trip-list",
  standalone: true,
  imports: [CommonModule, RouterModule, TripCardComponent],
  templateUrl: "./trip-list.component.html",
  styleUrls: ["./trip-list.component.css"]
})
export class TripListComponent implements OnInit {
  trips: Trip[] = [];
  loading = false;
  errorMsg = "";

  constructor(private api: TripService) {}

  ngOnInit(): void {
    this.loadTrips();
  }

  loadTrips(): void {
    this.loading = true;
    this.errorMsg = "";
    this.api.list().subscribe({
      next: t => {
        this.trips = t;
        this.loading = false;
      },
      error: e => {
        this.errorMsg = `Could not load trips: ${e?.message ?? e}`;
        this.loading = false;
      }
    });
  }

  handleDelete(code: string): void {
    if (!confirm(`Delete trip ${code}?`)) {
      return;
    }
    this.api.remove(code).subscribe({
      next: () => {
        this.trips = this.trips.filter(trip => trip.code !== code);
      },
      error: e => {
        alert(`Delete failed: ${e?.message ?? e}`);
      }
    });
  }
}
